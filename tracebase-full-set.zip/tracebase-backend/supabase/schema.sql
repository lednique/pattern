-- ============================================================================
-- TraceBase — схема базы данных Supabase
-- Выполните этот скрипт в Supabase: Dashboard → SQL Editor → New query → Run
-- ============================================================================

-- Расширение для генерации UUID (обычно уже включено)
create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Платежи (создаются при инициации оплаты, обновляются вебхуком ЮKassa)
-- ---------------------------------------------------------------------------
create table if not exists public.payments (
  id          uuid primary key default gen_random_uuid(),
  inv_id      bigint unique,               -- номер заказа Robokassa
  yookassa_id text unique,                 -- (зарезервировано)
  robokassa_id text,                       -- id операции в Robokassa
  tier        text not null check (tier in ('basic','deluxe')),
  email       text,                        -- email покупателя
  amount      text,                        -- сумма (строка)
  "currency"  text not null default 'RUB'  -- RUB or USD
              check ("currency" in ('RUB','USD')),
  status      text not null default 'pending'
              check (status in ('pending','succeeded','canceled')),
  key_id      uuid,                        -- ссылка на выданный ключ
  created_at  timestamptz not null default now(),
  paid_at     timestamptz
);

-- ---------------------------------------------------------------------------
-- Ключи доступа (генерируются вебхуком после успешной оплаты)
--   status: paid (оплачен, ещё не активирован) → activated (привязан к Figma)
-- ---------------------------------------------------------------------------
create table if not exists public.keys (
  id            uuid primary key default gen_random_uuid(),
  key           text unique not null,      -- формат XXXX-XXXX-XXXX-XXXX
  tier          text not null check (tier in ('basic','deluxe')),
  email         text,                      -- email покупателя
  status        text not null default 'paid'
                check (status in ('paid','activated')),
  figma_user_id text,                      -- ID аккаунта Figma (при активации)
  activated_at  timestamptz,
  created_at    timestamptz not null default now(),
  expires_at    timestamptz                -- NULL = бессрочный
);

-- ---------------------------------------------------------------------------
-- Безопасность: RLS включён, политик нет → анонимный доступ запрещён.
-- Сервер Vercel работает через service_role key (обходит RLS).
-- ---------------------------------------------------------------------------
alter table public.payments enable row level security;
alter table public.keys enable row level security;

-- ---------------------------------------------------------------------------
-- Промокоды (управляются в личном кабинете)
-- ---------------------------------------------------------------------------
create table if not exists public.coupons (
  id         uuid primary key default gen_random_uuid(),
  code       text unique not null,           -- промокод (верхний регистр)
  percent    integer not null check (percent between 1 and 100),
  created_at timestamptz not null default now()
);

-- Полезные индексы
create index if not exists idx_keys_key on public.keys (key);
create index if not exists idx_coupons_code on public.coupons (code);
create index if not exists idx_keys_figma on public.keys (figma_user_id);
create index if not exists idx_payments_yookassa on public.payments (yookassa_id);
