/* ============================================================================
 * POST/GET /api/robokassa-result — ResultURL Robokassa
 * Robokassa шлёт сюда уведомление об оплате (GET или POST form-urlencoded)
 * с параметрами OutSum, InvId, SignatureValue.
 * Подпись ResultURL: md5(OutSum:InvId:Password2).
 * Ответ ОБЯЗАТЕЛЬНО: "OK<InvId>" (текстом), иначе Robokassa повторяет запрос.
 * ==========================================================================*/
'use strict';
const crypto = require('crypto');
const { cors, readBody, sbReq, genKey } = require('./_shared');

const PASS2 = process.env.ROBO_PASS2 || '';

function parseForm(raw) {
  const out = {};
  String(raw || '').split('&').forEach((pair) => {
    const i = pair.indexOf('=');
    if (i > 0) out[decodeURIComponent(pair.slice(0, i))] = decodeURIComponent(pair.slice(i + 1).replace(/\+/g, ' '));
  });
  return out;
}

module.exports = async (req, res) => {
  cors(res);
  try {
    let params;
    if (req.method === 'POST') {
      params = parseForm(await readBody(req));
    } else {
      const qs = (req.url.split('?')[1] || '');
      params = parseForm(qs);
    }

    const OutSum = String(params.OutSum || '');
    const InvId = String(params.InvId || '');
    const sig = String(params.SignatureValue || '');

    if (!PASS2) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      return res.end('ROBO_PASS2 not configured');
    }
    const expected = crypto.createHash('md5').update(OutSum + ':' + InvId + ':' + PASS2).digest('hex');
    if (sig.toLowerCase() !== expected.toLowerCase()) {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      return res.end('bad signature');
    }

    // ищем платёж по номеру заказа
    const found = await sbReq('/rest/v1/payments?inv_id=eq.' + encodeURIComponent(InvId), 'GET');
    if (found && found.length && found[0].status === 'pending') {
      // генерируем ключ
      const created = await sbReq('/rest/v1/keys', 'POST', {
        key: genKey(),
        tier: found[0].tier,
        email: found[0].email || null,
        status: 'paid'
      }, 'return=representation');
      await sbReq('/rest/v1/payments?id=eq.' + found[0].id, 'PATCH', {
        status: 'succeeded',
        key_id: created[0].id,
        paid_at: new Date().toISOString()
      });
    }

    // Robokassa ждёт ровно "OK<InvId>"
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    return res.end('OK' + InvId);
  } catch (e) {
    console.error('[robokassa-result]', e && e.message ? e.message : e);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    return res.end('ERR');
  }
};
