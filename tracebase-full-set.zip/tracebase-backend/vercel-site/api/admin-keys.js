/* ============================================================================
 * Личный кабинет: управление ключами лицензий TraceBase
 * Доступ по паролю (env ADMIN_PASS), заголовок X-Admin-Pass.
 *   GET    /api/admin-keys            — список всех ключей
 *   POST   /api/admin-keys            — добавить ключ {tier, days?, email?}
 *   PATCH  /api/admin-keys            — изменить {key, tier?, days?, email?}
 *   DELETE /api/admin-keys            — удалить {key}
 * ==========================================================================*/
'use strict';
const { cors, send, readJson, sbReq, genKey } = require('./_shared');

const ADMIN_PASS = process.env.ADMIN_PASS || '';

function auth(req) {
  const h = req.headers || {};
  const got = h['x-admin-pass'] || h['X-Admin-Pass'];
  return ADMIN_PASS && got === ADMIN_PASS;
}

function daysToIso(days) {
  return days ? new Date(Date.now() + days * 864e5).toISOString() : null;
}

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (!auth(req)) return send(res, 401, { ok: false, error: 'unauthorized' });

  try {
    if (req.method === 'GET') {
      const keys = await sbReq('/rest/v1/keys?order=created_at.desc', 'GET');
      return send(res, 200, { ok: true, keys });
    }

    if (req.method === 'POST') {
      const b = await readJson(req);
      const tier = b.tier === 'basic' ? 'basic' : 'deluxe';
      const days = b.days ? Math.max(1, Math.min(3650, parseInt(b.days, 10) || 0)) : 0;
      const created = await sbReq('/rest/v1/keys', 'POST', {
        key: genKey(),
        tier,
        email: b.email || null,
        status: 'paid',
        expires_at: daysToIso(days)
      }, 'return=representation');
      return send(res, 200, { ok: true, key: created[0] });
    }

    if (req.method === 'PATCH') {
      const b = await readJson(req);
      const key = String(b.key || '').trim().toUpperCase();
      if (!key) return send(res, 400, { ok: false, error: 'no-key' });
      const found = await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'GET');
      if (!found || !found.length) return send(res, 404, { ok: false, error: 'not_found' });

      const patch = {};
      if (b.tier === 'basic' || b.tier === 'deluxe') patch.tier = b.tier;
      if (b.email !== undefined) patch.email = b.email || null;
      if (b.days !== undefined && b.days !== null && b.days !== '') {
        patch.expires_at = daysToIso(Math.max(1, Math.min(3650, parseInt(b.days, 10) || 0)));
      }
      if (!Object.keys(patch).length) return send(res, 400, { ok: false, error: 'nothing-to-change' });

      await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'PATCH', patch);
      const updated = await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'GET');
      return send(res, 200, { ok: true, key: updated[0] });
    }

    if (req.method === 'DELETE') {
      const b = await readJson(req);
      const key = String(b.key || '').trim().toUpperCase();
      await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'DELETE');
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    console.error('[admin-keys]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
