/* ============================================================================
 * POST /api/activate-key
 * Вызывается плагином TraceBase из Figma.
 * Тело: { key, figma_user_id }
 * Логика:
 *   - ключ не найден → { ok:false, error:'not_found' }
 *   - истёк          → { ok:false, error:'expired' }
 *   - уже активирован другим аккаунтом → { ok:false, error:'bound' }
 *   - первый ввод    → привязываем к figma_user_id (первая активация)
 * Успех: { ok:true, tier, expires_at }
 * ==========================================================================*/
'use strict';
const { cors, send, readJson, sbReq, isValidKey } = require('./_shared');

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  try {
    const body = await readJson(req);
    const key = String(body.key || '').trim().toUpperCase();
    const figmaUserId = String(body.figma_user_id || '').trim();

    if (!isValidKey(key)) return send(res, 200, { ok: false, error: 'format' });
    if (!figmaUserId) return send(res, 200, { ok: false, error: 'no-user' });

    const found = await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'GET');
    if (!found || !found.length) return send(res, 200, { ok: false, error: 'not_found' });
    const rec = found[0];

    if (rec.expires_at && new Date(rec.expires_at).getTime() < Date.now()) {
      return send(res, 200, { ok: false, error: 'expired' });
    }

    if (rec.status === 'activated') {
      if (rec.figma_user_id === figmaUserId) {
        return send(res, 200, { ok: true, tier: rec.tier, expires_at: rec.expires_at });
      }
      return send(res, 200, { ok: false, error: 'bound' });
    }

    // первая активация: привязываем ключ к аккаунту Figma
    await sbReq('/rest/v1/keys?key=eq.' + encodeURIComponent(key), 'PATCH', {
      status: 'activated',
      figma_user_id: figmaUserId,
      activated_at: new Date().toISOString()
    });
    return send(res, 200, { ok: true, tier: rec.tier, expires_at: rec.expires_at });
  } catch (e) {
    console.error('[activate-key]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
