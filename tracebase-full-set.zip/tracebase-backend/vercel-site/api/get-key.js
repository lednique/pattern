/* ============================================================================
 * GET /api/get-key?inv_id=123 (или ?payment=uuid)
 * Возвращает ключ после успешной оплаты (для страницы успеха).
 * ==========================================================================*/
'use strict';
const { cors, send, sbReq } = require('./_shared');

module.exports = async (req, res) => {
  cors(res);
  try {
    const qs = (req.url.split('?')[1] || '').split('&').reduce((acc, p) => {
      const i = p.indexOf('=');
      if (i > 0) acc[decodeURIComponent(p.slice(0, i))] = decodeURIComponent(p.slice(i + 1));
      return acc;
    }, {});
    const invId = qs.inv_id || qs.invId;
    const paymentId = qs.payment;

    let found = null;
    if (invId) found = await sbReq('/rest/v1/payments?inv_id=eq.' + encodeURIComponent(invId), 'GET');
    else if (paymentId) found = await sbReq('/rest/v1/payments?id=eq.' + encodeURIComponent(paymentId), 'GET');

    if (!found || !found.length || found[0].status !== 'succeeded') {
      return send(res, 404, { ok: false, error: 'not-paid' });
    }
    const keys = await sbReq('/rest/v1/keys?id=eq.' + found[0].key_id, 'GET');
    if (!keys || !keys.length) return send(res, 404, { ok: false, error: 'no-key' });

    return send(res, 200, { ok: true, key: keys[0].key, tier: keys[0].tier });
  } catch (e) {
    console.error('[get-key]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
