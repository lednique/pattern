/* ============================================================================
 * _shared.js — общие хелперы API TraceBase (Vercel serverless, Node 18+)
 * Ноль зависимостей: только встроенные модули и fetch.
 * ==========================================================================*/
'use strict';

const crypto = require('crypto');

/* ----------------------------- конфигурация из env ----------------------------- */
const SHOP_ID = process.env.YOOKASSA_SHOP_ID || '';
const SHOP_SECRET = process.env.YOOKASSA_SECRET_KEY || '';
const RETURN_URL = process.env.YOOKASSA_RETURN_URL || '';
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY || '';
/* Цены: Basic 3 мес 490 / год 1190; Deluxe 3 мес 990 / год 2290.
   Вне РФ — конвертация по курсу ЦБ + наценка 15%. */
const PRICES = {
  basic: { m3: Number(process.env.PRICE_BASIC_M3 || 490), y: Number(process.env.PRICE_BASIC_Y || 1190) },
  deluxe: { m3: Number(process.env.PRICE_DELUXE_M3 || 990), y: Number(process.env.PRICE_DELUXE_Y || 2290) }
};
const RUB_PER_USD = Number(process.env.RUB_PER_USD || 90); // курс ЦБ, обновляется крон-задачей

/* Региональные цены: определение страны по IP (2-букв. код) */
function countryOf(req) {
  const cf = (req.headers['cf-ipcountry'] || '').toString().toUpperCase();
  const vc = (req.headers['x-vercel-ip-country'] || '').toString().toUpperCase();
  return cf || vc || '';
}
function regionalPrices(req) {
  const country = countryOf(req);
  const isRU = country === '' || country === 'RU' || country === 'BY' || country === 'KZ' ||
               country === 'AM' || country === 'KG' || country === 'UZ' || country === 'TJ' ||
               country === 'MD' || country === 'AZ' || country === 'GE';
  if (isRU) return { base: 'RUB', currency: 'RUB', rate: 1, markup: 1 };
  const rate = RUB_PER_USD; // курс рубля к USD (конвертация)
  const markup = 1.15;      // +15% вне РФ
  return { base: 'USD', currency: 'USD', rate, markup };
}

/* ----------------------------- ключи ----------------------------- */
const CHARSET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // без I O 0 1

function genKey() {
  const seg = () => {
    let s = '';
    for (let i = 0; i < 4; i++) s += CHARSET[crypto.randomInt(CHARSET.length)];
    return s;
  };
  return seg() + '-' + seg() + '-' + seg() + '-' + seg();
}

function isValidKey(k) {
  return /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(k);
}

/* ----------------------------- HTTP-хелперы ----------------------------- */
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', (c) => { d += c; if (d.length > 1e6) req.destroy(); });
    req.on('end', () => resolve(d));
    req.on('error', reject);
  });
}

async function readJson(req) {
  const raw = await readBody(req);
  try { return JSON.parse(raw); } catch (e) { throw new Error('bad json'); }
}

/* Подпись вебхука ЮKassa: HMAC-SHA256(тело) секретным ключом магазина */
function verifySignature(rawBody, header) {
  if (!SHOP_SECRET || !header) return false;
  const expected = crypto.createHmac('sha256', SHOP_SECRET).update(rawBody).digest('hex');
  return header === expected;
}

/* ----------------------------- Supabase REST (service role) ----------------------------- */
/* ----------------------------- Supabase REST (service role) ----------------------------- */
/* Нормализуем базовый URL: убираем завершающие слеши и возможный суффикс /rest/v1,
   чтобы путь не задваивался (PGRST125 "Invalid path specified"). */
function sbBase() {
  return (SUPABASE_URL || '')
    .replace(/\/rest\/v1\/?$/, '')
    .replace(/\/+$/, '');
}

async function sbReq(path, method, body, prefer) {
  const base = sbBase();
  if (!base) {
    throw new Error('SUPABASE_URL is not set in Vercel env');
  }
  if (!SUPABASE_SERVICE_KEY) {
    throw new Error('SUPABASE_SERVICE_KEY is not set in Vercel env');
  }
  const headers = {
    apikey: SUPABASE_SERVICE_KEY,
    Authorization: 'Bearer ' + SUPABASE_SERVICE_KEY,
    'Content-Type': 'application/json'
  };
  if (prefer) headers.Prefer = prefer;
  const opts = { method, headers };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const full = base + path;
  const r = await fetch(full, opts);
  const text = await r.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
  if (!r.ok) {
    throw new Error('supabase ' + r.status + ' (url: ' + full + '): ' + (typeof data === 'string' ? data.slice(0, 300) : JSON.stringify(data).slice(0, 300)));
  }
  return data;
}

module.exports = {
  SHOP_ID, SHOP_SECRET, RETURN_URL, SUPABASE_URL, SUPABASE_SERVICE_KEY, PRICES, RUB_PER_USD, regionalPrices, countryOf,
  genKey, isValidKey, cors, send, readBody, readJson, verifySignature, sbReq
};
