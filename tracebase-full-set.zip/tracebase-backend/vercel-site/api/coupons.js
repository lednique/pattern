/* ============================================================================
 * Личный кабинет: управление промокодами (X-Admin-Pass)
 *   GET    /api/coupons            — список
 *   POST   /api/coupons            — создать {code, percent}
 *   PATCH  /api/coupons            — изменить {code, percent}
 *   DELETE /api/coupons            — удалить {code}
 * ==========================================================================*/
'use strict';
const { cors, send, readJson, sbReq } = require('./_shared');

const ADMIN_PASS = process.env.ADMIN_PASS || '';
function auth(req) {
  const h = req.headers || {};
  const got = h['x-admin-pass'] || h['X-Admin-Pass'];
  return ADMIN_PASS && got === ADMIN_PASS;
}

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (!auth(req)) return send(res, 401, { ok: false, error: 'unauthorized' });
  try {
    if (req.method === 'GET') {
      const c = await sbReq('/rest/v1/coupons?order=created_at.desc', 'GET');
      return send(res, 200, { ok: true, coupons: c });
    }
    if (req.method === 'POST') {
      const b = await readJson(req);
      const code = String(b.code || '').trim().toUpperCase();
      const percent = Math.max(1, Math.min(100, parseInt(b.percent, 10) || 0));
      if (!/^[A-Z0-9_-]{2,20}$/.test(code)) return send(res, 400, { ok: false, error: 'bad-code' });
      const created = await sbReq('/rest/v1/coupons', 'POST', { code, percent }, 'return=representation');
      return send(res, 200, { ok: true, coupon: created[0] });
    }
    if (req.method === 'PATCH') {
      const b = await readJson(req);
      const code = String(b.code || '').trim().toUpperCase();
      const found = await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(code), 'GET');
      if (!found || !found.length) return send(res, 404, { ok: false, error: 'not_found' });
      const percent = Math.max(1, Math.min(100, parseInt(b.percent, 10) || 0));
      await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(code), 'PATCH', { percent });
      const updated = await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(code), 'GET');
      return send(res, 200, { ok: true, coupon: updated[0] });
    }
    if (req.method === 'DELETE') {
      const b = await readJson(req);
      const code = String(b.code || '').trim().toUpperCase();
      await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(code), 'DELETE');
      return send(res, 200, { ok: true });
    }
    return send(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    console.error('[coupons]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
