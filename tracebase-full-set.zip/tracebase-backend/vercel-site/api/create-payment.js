/* ============================================================================
 * POST /api/create-payment — Robokassa
 * Тело: { tier, period: 'm3'|'y', email, coupon? }
 * Ответ: { ok, action, form, inv_id, amount, currency, discount, coupon_100 }
 *   coupon_100 = true → скидка 100%, ключ выдаётся сразу (без оплаты)
 * ==========================================================================*/
'use strict';
const crypto = require('crypto');
const { cors, send, readJson, sbReq, PRICES, regionalPrices, genKey } = require('./_shared');

const MERCHANT_LOGIN = process.env.ROBO_MERCHANT_LOGIN || '';
const PASS1 = process.env.ROBO_PASS1 || '';
const PASS2 = process.env.ROBO_PASS2 || '';
const IS_TEST = process.env.ROBO_ISTEST === '1';

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  try {
    const { tier, period, email, coupon } = await readJson(req);
    if (tier !== 'basic' && tier !== 'deluxe') return send(res, 400, { ok: false, error: 'bad-tier' });
    const per = period === 'y' ? 'y' : 'm3';
    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return send(res, 400, { ok: false, error: 'bad-email' });
    if (!MERCHANT_LOGIN || !PASS1 || !PASS2) return send(res, 500, { ok: false, error: 'robokassa-not-configured' });

    // --- цена с учётом региона ---
    const reg = regionalPrices(req);
    const baseRub = PRICES[tier][per];
    let amount = baseRub;
    let discount = 0;
    let currency = 'RUB';

    // --- промокод ---
    if (coupon) {
      const code = String(coupon).trim().toUpperCase();
      const found = await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(code), 'GET');
      if (found && found.length) {
        discount = Math.round(baseRub * found[0].percent / 100);
        amount = baseRub - discount;
      } else {
        return send(res, 200, { ok: false, error: 'bad-coupon' });
      }
    }

    const paymentId = crypto.randomUUID();
    const invId = (Date.now() % 100000000) + Math.floor(Math.random() * 10000);

    // --- скидка 100% → выдаём ключ сразу ---
    if (discount >= baseRub) {
      const created = await sbReq('/rest/v1/keys', 'POST', {
        key: genKey(), tier, email: email || null, status: 'paid'
      }, 'return=representation');
      await sbReq('/rest/v1/payments', 'POST', {
        id: paymentId, inv_id: invId, tier, email, amount: '0', status: 'succeeded',
        key_id: created[0].id, paid_at: new Date().toISOString()
      });
      return send(res, 200, {
        ok: true, coupon_100: true, key: created[0].key, tier, payment_id: paymentId, inv_id: invId
      });
    }

    // --- конвертация вне РФ (+15%) ---
    // Округляем до целого доллара — та же цена, что показывает сайт (/api/prices)
    if (reg.base === 'USD') {
      amount = Math.round(amount / reg.rate * reg.markup);
      currency = 'USD';
    }

    const outSum = amount.toFixed(2);
    const sig = crypto.createHash('md5')
      .update(MERCHANT_LOGIN + ':' + outSum + ':' + invId + ':' + PASS1)
      .digest('hex');

    await sbReq('/rest/v1/payments', 'POST', {
      id: paymentId, inv_id: invId, tier, email, amount: String(amount), status: 'pending', currency
    });

    const form = {
      MerchantLogin: MERCHANT_LOGIN,
      OutSum: outSum,
      InvId: String(invId),
      SignatureValue: sig,
      Description: 'TraceBase ' + (tier === 'deluxe' ? 'Deluxe' : 'Basic') + ' ' + (per === 'y' ? '1 year' : '3 months'),
      Email: email
    };
    if (IS_TEST) form.IsTest = '1';

    return send(res, 200, {
      ok: true,
      action: 'https://auth.robokassa.ru/Merchant/Index.aspx',
      payment_id: paymentId,
      inv_id: invId,
      amount: Number(outSum),
      currency,
      discount,
      form
    });
  } catch (e) {
    console.error('[create-payment]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
