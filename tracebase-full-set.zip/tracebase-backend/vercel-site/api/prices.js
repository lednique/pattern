/* ============================================================================
 * GET /api/prices — цены (с учётом региона покупателя)
 * Возвращает: { basic: {m3, y}, deluxe: {m3, y}, currency, region, rub_per_usd }
 * Вне РФ цены конвертируются в USD по курсу + наценка 15%.
 * ==========================================================================*/
'use strict';
const { cors, send, PRICES, regionalPrices, countryOf, RUB_PER_USD } = require('./_shared');

module.exports = async (req, res) => {
  cors(res);
  const reg = regionalPrices(req);
  const out = { basic: PRICES.basic, deluxe: PRICES.deluxe, region: countryOf(req) || 'RU' };
  if (reg.base === 'USD') {
    out.currency = 'USD';
    out.markup = 15;
    out.rub_per_usd = RUB_PER_USD;
    out.basic = { m3: Math.round(PRICES.basic.m3 / RUB_PER_USD * 1.15), y: Math.round(PRICES.basic.y / RUB_PER_USD * 1.15) };
    out.deluxe = { m3: Math.round(PRICES.deluxe.m3 / RUB_PER_USD * 1.15), y: Math.round(PRICES.deluxe.y / RUB_PER_USD * 1.15) };
  } else {
    out.currency = 'RUB';
    out.markup = 0;
  }
  return send(res, 200, out);
};
