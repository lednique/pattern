/* ============================================================================
 * GET /api/health — диагностика: какие env заданы, работает ли Supabase
 * Откройте в браузере: https://lednique.ru/api/health
 * ==========================================================================*/
'use strict';
const { cors, send, SHOP_ID, SHOP_SECRET, SUPABASE_URL, SUPABASE_SERVICE_KEY, PRICES } = require('./_shared');

function sbBase() {
  return (SUPABASE_URL || '')
    .replace(/\/rest\/v1\/?$/, '')
    .replace(/\/+$/, '');
}

// Роль ключа Supabase из JWT (полезно для диагностики: service_role обходит RLS, anon — нет)
function jwtRole(token) {
  try {
    const p = String(token || '').split('.')[1];
    const json = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
    return json.role || 'unknown';
  } catch (e) { return 'parse-error'; }
}

module.exports = async (req, res) => {
  cors(res);
  try {
    let supabase = 'not-tested';
    const base = sbBase();
    if (!SUPABASE_URL) {
      supabase = 'MISSING ENV (SUPABASE_URL)';
    } else if (!SUPABASE_SERVICE_KEY) {
      supabase = 'MISSING ENV (SUPABASE_SERVICE_KEY)';
    } else {
      try {
        const r = await fetch(base + '/rest/v1/payments?select=id&limit=1', {
          headers: { apikey: SUPABASE_SERVICE_KEY, Authorization: 'Bearer ' + SUPABASE_SERVICE_KEY }
        });
        supabase = r.ok ? 'ok (table payments доступна)' : 'HTTP ' + r.status + ': ' + (await r.text()).slice(0, 200);
      } catch (e) {
        supabase = 'ERROR: ' + (e.message || e);
      }
    }
    return send(res, 200, {
      ok: true,
      env: {
        prices: PRICES,
        rub_per_usd: process.env.RUB_PER_USD ? process.env.RUB_PER_USD : '90 (по умолчанию)',
        robo_merchant_login: process.env.ROBO_MERCHANT_LOGIN ? 'set' : 'MISSING',
        robo_pass1: process.env.ROBO_PASS1 ? 'set' : 'MISSING',
        robo_pass2: process.env.ROBO_PASS2 ? 'set' : 'MISSING',
        robo_istest: process.env.ROBO_ISTEST ? process.env.ROBO_ISTEST : '0 (боевой режим)',
        admin_pass: process.env.ADMIN_PASS ? 'set' : 'MISSING (нужен для кабинета)',
        yookassa_shop_id: SHOP_ID ? 'set (' + SHOP_ID.slice(0, 3) + '…)' : 'не используется (Robokassa)',
        yookassa_secret: SHOP_SECRET ? 'set' : 'не используется (Robokassa)',
        supabase_url: SUPABASE_URL ? SUPABASE_URL : 'MISSING',
        supabase_normalized: base || 'MISSING',
        supabase_service_key: SUPABASE_SERVICE_KEY ? 'set (role=' + jwtRole(SUPABASE_SERVICE_KEY) + ')' : 'MISSING',
        return_url: process.env.YOOKASSA_RETURN_URL ? 'set' : 'MISSING (YOOKASSA_RETURN_URL)'
      },
      prices: PRICES,
      supabase: supabase
    });
  } catch (e) {
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
