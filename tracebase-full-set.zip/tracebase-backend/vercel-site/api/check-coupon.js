/* ============================================================================
 * POST /api/check-coupon — проверка промокода (для страницы покупки)
 * Тело: { code } → { ok, percent }
 * ==========================================================================*/
'use strict';
const { cors, send, readJson, sbReq } = require('./_shared');

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  try {
    const { code } = await readJson(req);
    const c = String(code || '').trim().toUpperCase();
    if (!c) return send(res, 200, { ok: false, error: 'bad-code' });
    const found = await sbReq('/rest/v1/coupons?code=eq.' + encodeURIComponent(c), 'GET');
    if (!found || !found.length) return send(res, 200, { ok: false, error: 'not_found' });
    return send(res, 200, { ok: true, percent: found[0].percent });
  } catch (e) {
    return send(res, 500, { ok: false, error: 'server-error' });
  }
};
