/* ============================================================================
 * POST /api/yookassa-webhook
 * Уведомление ЮKassa об оплате. Проверяем подпись, помечаем платёж успешным
 * и генерируем ключ в Supabase.
 * ==========================================================================*/
'use strict';
const { cors, send, readBody, verifySignature, sbReq, genKey } = require('./_shared');

module.exports = async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') return send(res, 204, {});
  try {
    const raw = await readBody(req);
    if (!verifySignature(raw, req.headers['content-signature'])) {
      return send(res, 401, { ok: false, error: 'bad-signature' });
    }
    const ev = JSON.parse(raw);
    const pay = ev.object || {};

    if (ev.event === 'payment.succeeded' && pay.id) {
      const found = await sbReq('/rest/v1/payments?yookassa_id=eq.' + encodeURIComponent(pay.id), 'GET');
      if (found && found.length && found[0].status !== 'succeeded') {
        // генерируем ключ и сохраняем в Supabase
        const created = await sbReq('/rest/v1/keys', 'POST', {
          key: genKey(),
          tier: found[0].tier,
          email: found[0].email || null,
          status: 'paid'
        }, 'return=representation');
        await sbReq('/rest/v1/payments?id=eq.' + found[0].id, 'PATCH', {
          status: 'succeeded',
          key_id: created[0].id,
          paid_at: new Date().toISOString()
        });
      }
    } else if (ev.event === 'payment.canceled' && pay.id) {
      const found = await sbReq('/rest/v1/payments?yookassa_id=eq.' + encodeURIComponent(pay.id), 'GET');
      if (found && found.length && found[0].status === 'pending') {
        await sbReq('/rest/v1/payments?id=eq.' + found[0].id, 'PATCH', { status: 'canceled' });
      }
    }

    return send(res, 200, { ok: true });
  } catch (e) {
    console.error('[yookassa-webhook]', e && e.message ? e.message : e);
    return send(res, 500, { ok: false, error: 'server-error', detail: String(e && e.message || e) });
  }
};
