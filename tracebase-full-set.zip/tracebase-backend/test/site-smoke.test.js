#!/usr/bin/env node
/* Смоук-тест index.html (сайт покупки): мок-DOM + мок-fetch.
   Проверяет: язык по системе, переводы, рендер цен/валюты,
   промокод 100% → редирект на success, Enter в поле промокода. */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'vercel-site', 'index.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };

/* ---------- минимальный DOM ---------- */
const els = {};
function makeEl(id) {
  const el = {
    id, dataset: {}, textContent: '', innerHTML: '', className: '', value: '', disabled: false,
    classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } },
    _ls: {}, addEventListener(t, cb) { (this._ls[t] = this._ls[t] || []).push(cb); },
    dispatch(t, ev) { for (const cb of this._ls[t] || []) cb(ev || { target: this, key: undefined, preventDefault() {} }); },
    appendChild(c) { (this._children = this._children || []).push(c); if (c && c.innerHTML) this.innerHTML += c.innerHTML; },
    closest() { return null; }
  };
  els[id] = el;
  return el;
}
['langBtn','langFlag','langCode','langMenu','tiers','periodToggle','email','couponInput','couponApply','couponMsg','payBtn','msg'].forEach(makeEl);
els.email.value = 'buyer@example.com';
els.email._ls = {};
els.email.addEventListener = function (t, cb) { (this._ls[t] = this._ls[t] || []).push(cb); };
els.couponInput.value = 'FREE100';

const document = {
  getElementById: (id) => els[id] || makeEl(id),
  createElement: (tag) => ({
    style: {}, dataset: {}, innerHTML: '', textContent: '', className: '', value: '',
    classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } },
    _ls: {}, addEventListener(t, cb) { (this._ls[t] = this._ls[t] || []).push(cb); },
    dispatch(t, ev) { for (const cb of this._ls[t] || []) cb(ev || { target: this, preventDefault() {} }); },
    appendChild() {}, submit() { document._submitted = true; }
  }),
  querySelectorAll: (sel) => {
    if (sel === '[data-i18n]' || sel === '[data-i18n-html]') return [];
    if (sel === '#langMenu button') return [];
    if (sel.startsWith('#periodToggle button')) return els.periodToggle._children || [];
    return [];
  },
  querySelector: () => null,
  addEventListener() {},
  body: { appendChild() {} }
};
els.periodToggle._children = [
  { dataset: { period: 'm3' }, classList: { toggle() {} } },
  { dataset: { period: 'y' }, classList: { _s: new Set(['active']), toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; } } }
];

/* ---------- среда ---------- */
const sandbox = {
  console, setTimeout, clearTimeout, navigator: { language: 'ru-RU' },
  document, window: {}, localStorage: { getItem: () => null, setItem() {} },
  Intl, URLSearchParams, encodeURIComponent, decodeURIComponent,
  fetch: async (url, opts) => {
    if (String(url).includes('/api/prices')) {
      return { ok: true, json: async () => ({ basic: { m3: 490, y: 1190 }, deluxe: { m3: 990, y: 2290 }, currency: 'RUB' }) };
    }
    if (String(url).includes('/api/check-coupon')) {
      const body = JSON.parse(opts.body);
      if (body.code === 'FREE100') return { ok: true, json: async () => ({ ok: true, percent: 100 }) };
      if (body.code === 'S20') return { ok: true, json: async () => ({ ok: true, percent: 20 }) };
      return { ok: true, json: async () => ({ ok: false }) };
    }
    if (String(url).includes('/api/create-payment')) {
      const body = JSON.parse(opts.body);
      if (body.coupon === 'FREE100') {
        return { ok: true, json: async () => ({ ok: true, coupon_100: true, key: 'ABCD-EFGH-JKLM-NPQR', tier: 'deluxe' }) };
      }
      return { ok: true, json: async () => ({ ok: true, action: 'https://auth.robokassa.ru/Merchant/Index.aspx', form: { MerchantLogin: 'x' }, payment_id: 'p1' }) };
    }
    return { ok: false, json: async () => ({}) };
  }
};
sandbox.window.location = { href: '' };
sandbox.location = sandbox.window.location;
sandbox.window.location.href = '';

vm.createContext(sandbox);
vm.runInContext(js, sandbox);

(async () => {
  await new Promise((r) => setTimeout(r, 50));

  /* 1. язык по системе */
  ok(sandbox.LANG === 'ru', 'язык по системе (ru-RU → ru): ' + sandbox.LANG);
  ok(els.langFlag.textContent === '🇷🇺', 'флаг 🇷🇺 (не undefined)');
  ok(els.langCode.textContent === 'RU', 'код языка RU');

  /* 2. подзаголовок и тексты */
  ok(els.langMenu.innerHTML.includes('Русский'), 'меню языков: Русский');
  ok(/undefined/.test(els.langFlag.textContent + els.langMenu.innerHTML) === false, 'нет undefined в флагах/меню');

  /* 3. цены — рендер тарифов (период по умолчанию «1 год» → 1190/2290, разделитель — неразрывный пробел) */
  const tiersHtml = els.tiers.innerHTML;
  ok(tiersHtml.includes('190') && tiersHtml.includes('₽'), 'цена Basic 1 190 ₽');
  ok(tiersHtml.includes('290'), 'цена Deluxe 2 290');
  ok(/class="price"/.test(tiersHtml), 'цена рендерится');

  /* 4. переводы ключей */
  ok(sandbox.t('subtitle') === 'Получите личный лицензионный ключ', 'subtitle RU');
  ok(sandbox.t('license_tag') === 'Лицензия', 'license_tag RU');
  ok(sandbox.t('pay') === 'Оплатить и получить покупку', 'pay RU');
  ok(sandbox.t('step2d') === 'Прием платежей со всего мира', 'step2d RU');
  ok(sandbox.t('step1d').includes('Без скрытых платежей'), 'step1d RU без скрытых платежей');

  /* 5. промокод 20% */
  els.couponInput.value = 'S20';
  els.couponApply.dispatch('click');
  await new Promise((r) => setTimeout(r, 30));
  ok(sandbox.couponPercent === 20, 'промокод 20% применён');
  ok(els.couponMsg.textContent.includes('20'), 'сообщение о скидке 20%');

  /* 6. промокод 100% → редирект на success */
  els.couponInput.value = 'FREE100';
  els.selectedTier = 'deluxe';
  // выберем тариф кликом по карточке не можем (кнопки в innerHTML), зададим напрямую
  sandbox.selectedTier = 'deluxe';
  els.couponApply.dispatch('click');
  await new Promise((r) => setTimeout(r, 80));
  ok(sandbox.window.location.href.includes('/success.html?key='), '100% → редирект на success: ' + sandbox.window.location.href);
  ok(sandbox.window.location.href.includes('tier=deluxe'), 'редирект с tier');

  /* 7. Enter в поле промокода */
  sandbox.window.location.href = '';
  els.couponInput.value = 'FREE100';
  els.couponInput.dispatch('keydown', { key: 'Enter', preventDefault() {} });
  await new Promise((r) => setTimeout(r, 80));
  ok(sandbox.window.location.href.includes('/success.html?key='), 'Enter в промокоде → редирект на success');

  /* 8. обычная оплата — форма Robokassa */
  sandbox.window.location.href = '';
  els.couponInput.value = '';
  sandbox.couponPercent = 0;
  els.payBtn.dispatch('click');
  await new Promise((r) => setTimeout(r, 80));
  ok(sandbox.window.location.href === '', 'обычная оплата — без редиректа');

  console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
  process.exit(fail ? 1 : 0);
})();
