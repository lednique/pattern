#!/usr/bin/env node
/* Тест бэкенда TraceBase (Robokassa): платёж → ResultURL → ключ → активация → админка.
   Запуск: node test/backend.test.js  (из папки tracebase-backend) */
'use strict';
process.env.ROBO_MERCHANT_LOGIN = 'test-shop';
process.env.ROBO_PASS1 = 'pass1';
process.env.ROBO_PASS2 = 'pass2';
process.env.ROBO_ISTEST = '1';
process.env.ADMIN_PASS = 'admin-secret';
process.env.SUPABASE_URL = 'https://mock.supabase.co';
process.env.SUPABASE_SERVICE_KEY = 'svc-key';
process.env.PRICE_BASIC_M3 = '490'; process.env.PRICE_BASIC_Y = '1190';
process.env.PRICE_DELUXE_M3 = '990'; process.env.PRICE_DELUXE_Y = '2290';

const path = require('path');
const crypto = require('crypto');
const apiDir = path.join(__dirname, '..', 'vercel-site', 'api');

const db = { payments: [], keys: [], coupons: [] };
function eqFilter(row, q) {
  return Object.entries(q).every(([k, v]) => String(row[k]) === String(v));
}
function parseQuery(url) {
  const parsed = new URL(url);
  const pathPart = parsed.pathname;
  const qs = parsed.search.replace(/^\?/, '');
  const filters = {};
  if (qs) {
    for (const pair of qs.split('&')) {
      const i = pair.indexOf('=');
      const k = pair.slice(0, i);
      let v = decodeURIComponent(pair.slice(i + 1));
      if (v.startsWith('eq.')) v = v.slice(3);
      if (k === 'order') continue;
      filters[k] = v;
    }
  }
  return { table: pathPart.replace('/rest/v1/', ''), filters };
}

global.fetch = async (url, opts = {}) => {
  const u = String(url);
  if (u.startsWith('https://mock.supabase.co')) {
    const { table, filters } = parseQuery(u);
    const method = opts.method || 'GET';
    if (method === 'GET') {
      const rows = db[table].filter((r) => eqFilter(r, filters)).sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''));
      return { ok: true, status: 200, text: async () => JSON.stringify(rows), json: async () => rows };
    }
    if (method === 'POST') {
      const row = JSON.parse(opts.body || '{}');
      if (!row.created_at) row.created_at = new Date().toISOString();
      db[table].push(row);
      const rep = (opts.headers.Prefer || '').includes('return=representation') ? [row] : null;
      return { ok: true, status: 201, text: async () => JSON.stringify(rep), json: async () => rep };
    }
    if (method === 'PATCH') {
      const patch = JSON.parse(opts.body || '{}');
      db[table].filter((r) => eqFilter(r, filters)).forEach((r) => Object.assign(r, patch));
      return { ok: true, status: 200, text: async () => '[]', json: async () => [] };
    }
    if (method === 'DELETE') {
      const rows = db[table].filter((r) => eqFilter(r, filters));
      rows.forEach((r) => db[table].splice(db[table].indexOf(r), 1));
      return { ok: true, status: 200, text: async () => '[]', json: async () => [] };
    }
  }
  return { ok: false, status: 404, text: async () => '', json: async () => ({}) };
};

function makeReq(body, headers, method) {
  const req = { method: method || 'POST', headers: headers || {}, url: '/' };
  if (body !== undefined && body !== null) {
    req.on = (ev, cb) => { if (ev === 'data') cb(Buffer.from(body)); if (ev === 'end') cb(); };
  } else {
    req.on = () => {};
  }
  return req;
}
function makeRes() {
  const res = { _headers: {}, _code: 200, _body: '', setHeader(k, v) { this._headers[k] = v; }, writeHead(c, h) { this._code = c; Object.assign(this._headers, h || {}); }, end(b) { this._body = b || ''; } };
  return res;
}
const call = async (fn, body, headers, method) => { const res = makeRes(); await fn(makeReq(body, headers, method), res); let data = res._body; try { data = JSON.parse(res._body); } catch (e) {} return { code: res._code, data }; };

let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };

async function runAll() {
  /* 1. цены */
  const prices = await call(require(path.join(apiDir, 'prices.js')), null, null, 'GET');
  ok(prices.data.basic && prices.data.basic.m3 === 490 && prices.data.basic.y === 1190 && prices.data.deluxe.m3 === 990 && prices.data.deluxe.y === 2290, 'prices: 490/1190/990/2290');

  /* 2. create-payment (Robokassa) */
  const createPayment = require(path.join(apiDir, 'create-payment.js'));
  const cp = await call(createPayment, JSON.stringify({ tier: 'deluxe', email: 'buyer@example.com', period: 'm3' }));
  ok(cp.code === 200 && cp.data.ok && cp.data.action === 'https://auth.robokassa.ru/Merchant/Index.aspx', 'create-payment: action Robokassa');
  ok(cp.data.form.OutSum === '990.00', 'Deluxe 3 мес = 990: ' + cp.data.form.OutSum);
  const cpY = await call(createPayment, JSON.stringify({ tier: 'deluxe', email: 'b@e.c', period: 'y' }));
  ok(cpY.data.form.OutSum === '2290.00', 'Deluxe год = 2290: ' + cpY.data.form.OutSum);
  const cpB = await call(createPayment, JSON.stringify({ tier: 'basic', email: 'b@e.c', period: 'y' }));
  ok(cpB.data.form.OutSum === '1190.00', 'Basic год = 1190: ' + cpB.data.form.OutSum);
  const invId = cp.data.form.InvId;
  const expectedSig = crypto.createHash('md5').update('test-shop:990.00:' + invId + ':pass1').digest('hex');
  ok(cp.data.form.SignatureValue === expectedSig, 'подпись InitPayment md5 корректна');
  ok(cp.data.form.IsTest === '1', 'тестовый режим IsTest=1');
  const pend = db.payments.filter(function(p){ return p.inv_id === parseInt(invId, 10); });
  ok(pend.length === 1 && pend[0].status === 'pending' && pend[0].tier === 'deluxe' && Number(pend[0].amount) === 990, 'платёж записан (pending, inv_id, 990)');
  const bad = await call(createPayment, JSON.stringify({ tier: 'ultra', email: 'x@y.z' }));
  ok(bad.code === 400, 'неверный tier → 400');

  /* 3. ResultURL Robokassa */
  const result = require(path.join(apiDir, 'robokassa-result.js'));
  const outSum = '990.00';
  const rSig = crypto.createHash('md5').update(outSum + ':' + invId + ':pass2').digest('hex');
  const body = 'OutSum=' + outSum + '&InvId=' + invId + '&SignatureValue=' + rSig + '&InvId=' + invId;
  const formBody = 'OutSum=' + outSum + '&InvId=' + invId + '&SignatureValue=' + rSig;
  const wh = await call(result, formBody, { 'Content-Type': 'application/x-www-form-urlencoded' });
  ok(wh.code === 200 && wh.data === 'OK' + invId, 'ResultURL: ответ OK<InvId>');
  const paid = db.payments.filter(function(p){ return p.inv_id === parseInt(invId, 10); })[0];
  ok(paid && paid.status === 'succeeded', 'платёж → succeeded');
  const paidKey = db.keys[db.keys.length - 1];
  ok(paidKey && paidKey.tier === 'deluxe' && /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(paidKey.key), 'ключ сгенерирован');
  const badSig = await call(result, 'OutSum=' + outSum + '&InvId=' + invId + '&SignatureValue=deadbeef');
  ok(badSig.data === 'bad signature', 'неверная подпись → bad signature');
  await call(result, formBody, {});
  ok(db.keys.length === 1, 'повторный ResultURL не дублирует ключ');

  /* 4. get-key по inv_id */
  const getKey = require(path.join(apiDir, 'get-key.js'));
  const gk = await new Promise((resolve) => {
    const res = makeRes();
    getKey({ method: 'GET', url: '/api/get-key?inv_id=' + invId, headers: {} }, res).then(() => resolve({ code: res._code, data: JSON.parse(res._body || '{}') }));
  });
  ok(gk.code === 200 && gk.data.key === paidKey.key, 'get-key по inv_id');

  /* 5. активация */
  const activate = require(path.join(apiDir, 'activate-key.js'));
  const a1 = await call(activate, JSON.stringify({ key: 'ZZZZ-ZZZZ-ZZZZ-ZZZZ', figma_user_id: 'figma-1' }));
  ok(a1.data.ok === false && a1.data.error === 'not_found', 'несуществующий ключ');
  const a2 = await call(activate, JSON.stringify({ key: paidKey.key, figma_user_id: 'figma-1' }));
  ok(a2.data.ok === true && a2.data.tier === 'deluxe', 'первый ввод привязывает');
  ok(paidKey.status === 'activated' && paidKey.figma_user_id === 'figma-1', 'ключ activated');
  const a3 = await call(activate, JSON.stringify({ key: paidKey.key, figma_user_id: 'figma-2' }));
  ok(a3.data.ok === false && a3.data.error === 'bound', 'другой аккаунт → bound');
  const a4 = await call(activate, JSON.stringify({ key: paidKey.key, figma_user_id: 'figma-1' }));
  ok(a4.data.ok === true, 'тот же аккаунт повторно → ok');

  /* 6. админка (личный кабинет) */
  const admin = require(path.join(apiDir, 'admin-keys.js'));
  const unauth = await call(admin, null, {}, 'GET');
  ok(unauth.code === 401, 'админка без пароля → 401');
  const H = { 'X-Admin-Pass': 'admin-secret' };
  const list = await call(admin, null, H, 'GET');
  ok(list.code === 200 && list.data.keys.length === 1, 'GET: список ключей');
  const addK = await call(admin, JSON.stringify({ tier: 'basic', days: 30, email: 'a@b.c' }), H, 'POST');
  ok(addK.code === 200 && addK.data.key && addK.data.key.tier === 'basic' && addK.data.key.expires_at, 'POST: добавлен ключ Basic на 30 дней');
  const newKey = addK.data.key.key;
  const upd = await call(admin, JSON.stringify({ key: newKey, tier: 'deluxe', days: 90 }), H, 'PATCH');
  ok(upd.code === 200 && upd.data.key.tier === 'deluxe', 'PATCH: версия изменена на Deluxe');
  const del = await call(admin, JSON.stringify({ key: newKey }), H, 'DELETE');
  ok(del.code === 200, 'DELETE: ключ удалён');
  const list2 = await call(admin, null, H, 'GET');
  ok(list2.data.keys.length === 1, 'после удаления остался 1 ключ');

  /* 7. Промокоды */
  const coupons = require(path.join(apiDir, 'coupons.js'));
  const cu = await call(coupons, null, {}, 'GET');
  ok(cu.code === 401, 'промокоды без пароля → 401');
  const cAdd = await call(coupons, JSON.stringify({ code: 'SUMMER20', percent: 20 }), H, 'POST');
  ok(cAdd.code === 200 && cAdd.data.coupon && cAdd.data.coupon.percent === 20, 'промокод создан');
  const cEdit = await call(coupons, JSON.stringify({ code: 'SUMMER20', percent: 50 }), H, 'PATCH');
  ok(cEdit.code === 200 && cEdit.data.coupon.percent === 50, 'промокод изменён (50%)');
  const cList = await call(coupons, null, H, 'GET');
  ok(cList.data.coupons.length === 1, 'промокод в списке');
  const cDel = await call(coupons, JSON.stringify({ code: 'SUMMER20' }), H, 'DELETE');
  ok(cDel.code === 200, 'промокод удалён');

  /* 8. create-payment с промокодом 100% → ключ сразу */
  const cp2 = await call(createPayment, JSON.stringify({ tier: 'basic', email: 'free@e.c', period: 'm3', coupon: 'FREE100' }));
  // создадим промокод 100% на сервере-моке напрямую
  db.coupons = [{ code: 'FREE100', percent: 100 }];
  const cp3 = await call(createPayment, JSON.stringify({ tier: 'basic', email: 'free@e.c', period: 'm3', coupon: 'FREE100' }));
  ok(cp3.data.ok === true && cp3.data.coupon_100 === true && cp3.data.key && /^[A-Z2-9]{4}-/.test(cp3.data.key), 'промокод 100%: ключ сразу');
  ok(cp3.data.key === db.keys[db.keys.length - 1].key, 'ключ сохранён в БД');
  // неверный промокод
  const cpBad = await call(createPayment, JSON.stringify({ tier: 'basic', email: 'a@b.c', period: 'm3', coupon: 'NOPE' }));
  ok(cpBad.data.ok === false && cpBad.data.error === 'bad-coupon', 'неверный промокод → bad-coupon');
  // промокод 20% на Deluxe 3 мес: 990 - 198 = 792
  db.coupons = [{ code: 'S20', percent: 20 }];
  const cpD = await call(createPayment, JSON.stringify({ tier: 'deluxe', email: 'a@b.c', period: 'm3', coupon: 'S20' }));
  ok(cpD.data.form.OutSum === '792.00', 'промокод 20%: 792.00 (' + cpD.data.form.OutSum + ')');

  /* 9. Региональные цены (заголовок cf-ipcountry) */
  const pricesFn = require(path.join(apiDir, 'prices.js'));
  const pricesUS = await call(pricesFn, null, { 'cf-ipcountry': 'US' }, 'GET');
  ok(pricesUS.data.currency === 'USD' && pricesUS.data.basic.y === Math.round(1190 / 90 * 1.15), 'вне РФ: USD +15% (basic год ' + pricesUS.data.basic.y + ')');
  const pricesRU = await call(pricesFn, null, { 'cf-ipcountry': 'RU' }, 'GET');
  ok(pricesRU.data.currency === 'RUB' && pricesRU.data.basic.y === 1190, 'в РФ: RUB без наценки');
  // платёж для US: целые доллары, совпадает с ценой на сайте
  const cpUS = await call(createPayment, JSON.stringify({ tier: 'deluxe', email: 'us@buyer.com', period: 'y' }), { 'x-vercel-ip-country': 'US' });
  const usExpected = Math.round(2290 / 90 * 1.15);
  ok(cpUS.data.ok && cpUS.data.currency === 'USD' && cpUS.data.form.OutSum === usExpected + '.00', 'вне РФ: платёж в целых долларах ' + cpUS.data.form.OutSum + ' (' + usExpected + ')');
  const usPend = db.payments.filter(function (p) { return p.inv_id === parseInt(cpUS.data.form.InvId, 10); });
  ok(usPend.length === 1 && usPend[0].currency === 'USD' && Number(usPend[0].amount) === usExpected, 'USD-платёж записан с валютой USD');

  /* 10. CORS */
  const res = makeRes();
  await require(path.join(apiDir, 'prices.js'))({ method: 'GET', url: '/', headers: {} }, res);
  ok(res._headers['Access-Control-Allow-Origin'] === '*', 'CORS');

  console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
  process.exit(fail ? 1 : 0);
}
runAll().catch((e) => { console.error('Харнесс упал:', e); process.exit(1); });
