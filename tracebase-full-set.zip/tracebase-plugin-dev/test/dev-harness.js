#!/usr/bin/env node
/* Харнесс DEV-версии TraceBase: без лицензии, все функции, без лимитов.
   Запуск: node test/dev-harness.js */
'use strict';
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('ui.html', 'utf8');
const script = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1])[0];

/* ---------- фейковый DOM ---------- */
const els = {};
function makeEl(id) {
  const el = {
    id, style: { setProperty() {} },
    classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } },
    dataset: {}, value: '', checked: false, disabled: false, textContent: '', innerHTML: '',
    _children: null, _ls: {},
    appendChild(c) { (this._children = this._children || []).push(c); },
    addEventListener(t, cb) { (this._ls[t] = this._ls[t] || []).push(cb); },
    dispatch(t, ev) { for (const cb of this._ls[t] || []) cb(ev || { target: this }); },
    closest() { return null; }
  };
  els[id] = el;
  return el;
}
const NEEDED = ['langBtn','langFlag','langCode','langMenu','licBadge','mainCard','mainCard2','insertBtn','modeSeg','cardHt','cardBw','cardColor','cardAscii','status','pv','pvEmpty','pvNa','spinner','selName','selSize','thrMin','thrMinOut','thrMax','thrMaxOut','bwSmooth','bwSmoothOut','bwPoints','bwPointsOut','bwInvert','colors','colorsOut','cSmooth','cSmoothOut','cPoints','cPointsOut','fs','fsOut','thrAsciiMin','thrAsciiMax','thrAsciiOut','charset','asciiInvert','htOn','htBody','htColorRow','htColorSeg','htCell','htCellOut','htThrMin','htThrMax','htThrOut','htThrRow','colorModeSeg','shapeSeg','starSwitch','starKnob','zoom','zoomOut'];
for (const id of NEEDED) makeEl(id);
els.pv.width = 332; els.pv.height = 186;
els.pv.getContext = () => ({ clearRect() {}, save() {}, restore() {}, translate() {}, scale() {}, fillRect() {}, fillText() {}, beginPath() {}, moveTo() {}, lineTo() {}, bezierCurveTo() {}, closePath() {}, fill() {}, set fillStyle(v) {}, get fillStyle() { return '#000'; }, set globalCompositeOperation(v) {} });
els.thrMin.value = '0'; els.thrMax.value = '128';
els.thrMin.parentElement = { style: { setProperty() {} } };
els.thrMax.parentElement = els.thrMin.parentElement;
els.thrAsciiMin.parentElement = els.thrMin.parentElement;
els.thrAsciiMax.parentElement = els.thrMin.parentElement;
els.htThrMin.parentElement = els.thrMin.parentElement;
els.htThrMax.parentElement = els.thrMin.parentElement;
els.thrOut = makeEl('thrOut'); els.thrAsciiMin.value = '0'; els.thrAsciiMax.value = '128'; els.htThrMin.value = '0'; els.htThrMax.value = '128';
els.bwSmooth.value = '55'; els.bwPoints.value = '50';
els.colors.value = '12'; els.cSmooth.value = '45'; els.cPoints.value = '50';
els.fs.value = '10'; els.htCell.value = '8';
els.zoom.value = '100';
els.charset.value = 'classic';
els.charset._children = ['classic','detailed','minimal','blocks'].map((v) => ({ value: v, textContent: '', dataset: { i18n: 'charset_' + v } }));
els.pvNa.classList.add('hidden');
els.pvNa.dataset.i18n = 'ht_preview_na';
els.insertBtn.dataset.i18n = 'insert';
els.selName.dataset.i18n = 'select_empty';
els.selSize.dataset.i18n = 'select_hint';
els.pvEmpty.dataset.i18n = 'select_hint';
els.modeSeg._children = ['bw','color','ascii'].map((m) => { const b = { tagName: 'BUTTON', dataset: { mode: m, i18n: 'mode_' + m }, classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, closest: (s) => (s === 'button' ? b : null) }; return b; });
function segBtn(tag, key, val) {
  const b = { tagName: tag, dataset: {}, classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, _ls: {}, addEventListener() {}, closest: (s) => (s === 'button' ? b : null) };
  b.dataset[key] = val;
  return b;
}
els.shapeSeg._children = [segBtn('BUTTON','shape','circle'), segBtn('BUTTON','shape','cross'), segBtn('BUTTON','shape','heart'), segBtn('BUTTON','shape','star')];
els.starSwitch.closest = (s) => (s === '#starSwitch' ? els.starSwitch : null);
els.colorModeSeg._children = ['simple','adaptive'].map((m) => segBtn('BUTTON','colormode',m));

const document = {
  getElementById: (id) => els[id] || makeEl(id),
  createElement: (tag) => (tag === 'button' ? { innerHTML: '', dataset: {}, classList: { add() {}, toggle() {}, remove() {} }, addEventListener() {} } : { style: {}, getContext: () => ({}) }),
  querySelector: (sel) => (sel === '.starBtn' ? els.shapeSeg._children[3] : null),
  querySelectorAll: (sel) => {
    const m = sel.match(/^#([\w-]+)\s+(\w+)$/);
    if (m) {
      const root = els[m[1]];
      return root && root._children ? root._children.filter((c) => (c.tagName || '').toLowerCase() === m[2]) : [];
    }
    if (sel === 'select option[data-i18n]') return els.charset._children;
    if (sel === '[data-i18n]') {
      const a = els.modeSeg._children.slice();
      a.push(els.insertBtn, els.selName, els.selSize, els.pvEmpty, els.pvNa);
      return a;
    }
    return [];
  },
  addEventListener() {},
  body: { classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, scrollHeight: 700 }
};

const cache = {};
const sent = [];
let msgHandlers = [];
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  Uint8Array, Uint8ClampedArray, Int32Array, Float32Array, Array, Math, JSON, Number, String, Object, Map, Set, Promise, URL: { createObjectURL: () => 'blob:x', revokeObjectURL: () => {} },
  document,
  parent: {
    postMessage: (m) => {
      sent.push(m);
      const pm = m.pluginMessage;
      setTimeout(() => {
        if (pm.type === 'get-user') emit({ data: { pluginMessage: { type: 'user', id: 'dev-user', real: true } } });
        else if (pm.type === 'cache-get') emit({ data: { pluginMessage: { type: 'cache-get', key: pm.key, value: cache[pm.key] !== undefined ? cache[pm.key] : null } } });
        else if (pm.type === 'cache-set') cache[pm.key] = pm.value;
      }, 0);
    }
  },
  addEventListener: (t, cb) => msgHandlers.push(cb),
  removeEventListener: () => {},
  window: null
};
sandbox.window = sandbox;
function emit(msg) { for (const cb of msgHandlers) cb(msg); if (sandbox.onmessage) sandbox.onmessage(msg); }
sandbox.Image = class { set src(v) {} };

vm.createContext(sandbox);
vm.runInContext(script, sandbox, { filename: 'ui.html' });
vm.runInContext('globalThis.__api = { state, t, setLang, LANG: () => LANG };', sandbox);
const api = sandbox.__api;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };

async function runAll() {
  await wait(600);

  /* --- нет лицензии: нет экрана блокировки, нет лимитов --- */
  ok(!html.includes('licCard') && !html.includes('TRIAL_LIMIT') && !html.includes('activate-key'), 'в коде нет лицензии');
  ok(html.includes('>DEV</b>'), 'бейдж DEV в шапке');

  /* --- все функции доступны сразу --- */
  ok(!els.modeSeg._children[2].classList.contains('hidden'), 'ASCII доступен');
  ok(!els.cardHt.classList.contains('hidden'), 'halftone доступен');

  /* --- вставка без ограничений: 12 раз подряд --- */
  let inserted = 0;
  for (let i = 0; i < 12; i++) {
    vm.runInContext('state.hasImage = true; state.finalSvg = "<svg width=\\"10\\" height=\\"10\\"/>"; state.finalAscii = null; state.busy = false;', sandbox);
    els.insertBtn.disabled = false;
    els.insertBtn.dispatch('click');
    await wait(120);
    inserted++;
  }
  const svgMsgs = sent.filter((m) => m.pluginMessage && m.pluginMessage.type === 'insert-svg').length;
  ok(svgMsgs === 12, '12 вставок подряд, insert-svg отправлен 12 раз (' + svgMsgs + ')');
  ok(!els.mainCard.classList.contains('hidden'), 'интерфейс не блокируется');
  ok(!els.licBadge.innerHTML.includes('0/'), 'счётчика нет');

  /* --- языки --- */
  vm.runInContext("setLang('ru')", sandbox);
  await wait(50);
  ok(els.modeSeg._children[0].textContent === 'Ч/Б', 'русский: Ч/Б');
  vm.runInContext("setLang('en')", sandbox);
  await wait(50);
  ok(els.modeSeg._children[0].textContent === 'B/W', 'английский: B/W');

  /* --- звезда-тумблер --- */
  els.shapeSeg.dispatch('click', { target: els.shapeSeg._children[3] });
  await wait(200);
  ok(api.state.shape === 'star5', 'звезда 5');
  els.shapeSeg.dispatch('click', { target: els.starSwitch });
  await wait(200);
  ok(api.state.shape === 'star4' && els.starKnob.textContent === '4', 'тумблер → 4');

  /* --- превью: слайдер масштаба есть; цвет-halftone → недоступно --- */
  ok(els.zoom && els.zoom.value === '100', 'слайдер масштаба есть');
  els.htOn.checked = true; els.htOn.dispatch('change');
  els.modeSeg.dispatch('click', { target: els.modeSeg._children[1] });
  vm.runInContext('state.hasImage = true; state.working = { data: new Uint8ClampedArray(4), width: 1, height: 1 }; doTrace();', sandbox);
  await wait(100);
  ok(!els.pvNa.classList.contains('hidden'), 'цвет-halftone: превью недоступно');
  els.htOn.checked = false; els.htOn.dispatch('change');
  await wait(100);

  console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
  process.exit(fail ? 1 : 0);
}
runAll().catch((e) => { console.error('Харнесс упал:', e); process.exit(1); });
