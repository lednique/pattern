#!/usr/bin/env bash
# Сборка ui.html TraceBase: подставляет core.js, i18n.js, шрифт Montserrat, логотип
set -e
cd "$(dirname "$0")"
python3 - <<'PY'
import pathlib
root = pathlib.Path('.')
core = (root / 'src' / 'core.js').read_text(encoding='utf-8')
i18n = (root / 'src' / 'i18n.js').read_text(encoding='utf-8')
mont = (root / 'src' / 'assets' / 'mont.css').read_text(encoding='utf-8')
logo = (root / 'src' / 'assets' / 'logo.b64').read_text(encoding='utf-8').strip()
logoLed = (root / 'src' / 'assets' / 'LEDNIQUE.b64').read_text(encoding='utf-8').strip()
tpl = (root / 'src' / 'ui-template.html').read_text(encoding='utf-8')

for ph, val in [('__MONT_CSS__', mont), ('__LOGO_B64__', logo), ('__LOGO_LED_B64__', logoLed), ('__I18N_JS__', i18n), ('__CORE_JS__', core)]:
    if ph not in tpl:
        raise SystemExit(f'Плейсхолдер {ph} не найден в шаблоне')
    tpl = tpl.replace(ph, val)

(root / 'ui.html').write_text(tpl, encoding='utf-8')
print(f'ui.html собран: {len(tpl):,} байт')
PY
