/* ============================================================================
 * core.js — чистые алгоритмы трассировки изображений (без DOM).
 * Используется и в UI плагина, и в тестах (Node).
 * Входные изображения: { data: Uint8ClampedArray (RGBA), width, height }
 * ==========================================================================*/
'use strict';

(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TracerCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {

  const LR = 0.2126, LG = 0.7152, LB = 0.0722;

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  function lumAt(data, i) {
    return data[i] * LR + data[i + 1] * LG + data[i + 2] * LB;
  }

  /* ---------- 1. Ч/Б порог (диапазон яркости) ---------- */
  // Возвращает бинарную маску (Uint8Array, 1 = чернила).
  // Чернила = пиксели, яркость которых попадает в диапазон [minT, maxT].
  // minT и maxT — в 0..255. Прозрачные пиксели всегда остаются фоном.
  function thresholdBW(image, minT, maxT, invert) {
    const { data, width: w, height: h } = image;
    const out = new Uint8Array(w * h);
    const lo = Math.min(minT, maxT), hi = Math.max(minT, maxT);
    for (let p = 0, i = 0; p < w * h; p++, i += 4) {
      if (data[i + 3] < 128) continue; // прозрачный — фон
      const L = lumAt(data, i);
      const inRange = L >= lo && L <= hi;
      out[p] = (inRange !== invert) ? 1 : 0;
    }
    return out;
  }

  /* ---------- 2. Удаление мелких компонент (шума) ---------- */
  function removeSmallComponents(mask, w, h, minArea) {
    if (minArea <= 0) return mask;
    const out = new Uint8Array(mask);
    const visited = new Uint8Array(w * h);
    const queue = new Int32Array(w * h);
    for (let s = 0; s < w * h; s++) {
      if (!out[s] || visited[s]) continue;
      let head = 0, tail = 0;
      queue[tail++] = s;
      visited[s] = 1;
      while (head < tail) {
        const p = queue[head++];
        const x = p % w, y = (p / w) | 0;
        if (x > 0)        { const q = p - 1;     if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (x < w - 1)    { const q = p + 1;     if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (y > 0)        { const q = p - w;     if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (y < h - 1)    { const q = p + w;     if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (x > 0 && y > 0)       { const q = p - w - 1; if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (x < w - 1 && y > 0)   { const q = p - w + 1; if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (x > 0 && y < h - 1)   { const q = p + w - 1; if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
        if (x < w - 1 && y < h - 1){ const q = p + w + 1; if (!visited[q] && out[q]) { visited[q] = 1; queue[tail++] = q; } }
      }
      if (tail < minArea) for (let k = 0; k < tail; k++) out[queue[k]] = 0;
    }
    return out;
  }

  /* ---------- 3. Дилатация маски (8-соседи) ---------- */
  function dilate(mask, w, h) {
    const out = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!mask[y * w + x]) continue;
        for (let dy = -1; dy <= 1; dy++) {
          const yy = y + dy;
          if (yy < 0 || yy >= h) continue;
          for (let dx = -1; dx <= 1; dx++) {
            const xx = x + dx;
            if (xx < 0 || xx >= w) continue;
            out[yy * w + xx] = 1;
          }
        }
      }
    }
    return out;
  }

  // Сглаживание бинарной маски: в каждой ячейке 2×2, где три пикселя залиты,
  // заполняем четвёртый — ступенчатые уголки превращаются в гладкие диагонали
  // (границы цветов становятся менее «лесенкой»).
  function smoothMaskCorners(mask, w, h) {
    const out = mask.slice();
    for (let y = 0; y < h - 1; y++) {
      for (let x = 0; x < w - 1; x++) {
        const a = mask[y * w + x], b = mask[y * w + x + 1];
        const c = mask[(y + 1) * w + x], d = mask[(y + 1) * w + x + 1];
        if (a + b + c + d === 3) {
          out[y * w + x] = 1; out[y * w + x + 1] = 1;
          out[(y + 1) * w + x] = 1; out[(y + 1) * w + x + 1] = 1;
        }
      }
    }
    return out;
  }

  /* ---------- 4. Марширующие квадраты: контуры бинарной маски ---------- */
  // Контур идёт по рёбрам пикселей (граница между «чернильным» и пустым пикселем),
  // вершины — в целочисленных координатах сетки. Возвращает массив замкнутых
  // контуров; каждый контур — массив [x, y].
  function traceContours(mask, w, h) {
    const ink = (x, y) => (x < 0 || y < 0 || x >= w || y >= h) ? 0 : mask[y * w + x];
    const segs = [];
    const midAdj = new Map();
    const addSeg = (x1, y1, x2, y2) => {
      const id = segs.length;
      segs.push([x1, y1, x2, y2]);
      const k1 = x1 + ',' + y1, k2 = x2 + ',' + y2;
      let a = midAdj.get(k1); if (!a) { a = []; midAdj.set(k1, a); } a.push(id);
      a = midAdj.get(k2); if (!a) { a = []; midAdj.set(k2, a); } a.push(id);
    };

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const v = mask[y * w + x];
        // правое ребро пикселя (x+1, y)-(x+1, y+1)
        if (x + 1 < w) {
          if (ink(x + 1, y) !== v) addSeg(x + 1, y, x + 1, y + 1);
        } else if (v === 1) addSeg(w, y, w, y + 1);   // правая граница кадра
        // нижнее ребро пикселя (x, y+1)-(x+1, y+1)
        if (y + 1 < h) {
          if (ink(x, y + 1) !== v) addSeg(x, y + 1, x + 1, y + 1);
        } else if (v === 1) addSeg(x, h, x + 1, h);   // нижняя граница кадра
        // левая и верхняя границы кадра
        if (x === 0 && v === 1) addSeg(0, y, 0, y + 1);
        if (y === 0 && v === 1) addSeg(x, 0, x + 1, 0);
      }
    }

    // --- Сборка сегментов в замкнутые контуры ---
    // Сначала спариваем сегменты в каждом узле сетки:
    //   степень 2 — очевидная пара; степень 4 (шахматный узор) — диагональная
    //   пара по узору пикселей. Тогда каждый контур гарантированно замкнут.
    const nextOf = new Map();
    for (const [key, adj] of midAdj) {
      const comma = key.indexOf(',');
      const i = parseFloat(key.slice(0, comma)), j = parseFloat(key.slice(comma + 1));
      if (adj.length === 2) {
        nextOf.set(adj[0] + '@' + key, adj[1]);
        nextOf.set(adj[1] + '@' + key, adj[0]);
      } else if (adj.length === 4) {
        const dirOf = {};
        for (const s of adj) {
          const seg = segs[s];
          let ox, oy;
          if (seg[0] === i && seg[1] === j) { ox = seg[2]; oy = seg[3]; }
          else { ox = seg[0]; oy = seg[1]; }
          const dx = ox - i, dy = oy - j;
          const d = dx === 0 ? (dy < 0 ? 'up' : 'down') : (dx < 0 ? 'left' : 'right');
          dirOf[d] = s;
        }
        // пиксели вокруг узла: TL=(i-1,j-1), TR=(i,j-1), BL=(i-1,j), BR=(i,j)
        // степень 4 бывает только в шахматном узоре; спариваем по залитой диагонали:
        //   TL+BR чернильные → пары (up,left) и (down,right)
        //   TR+BL чернильные → пары (up,right) и (left,down)
        const tl = ink(i - 1, j - 1), br = ink(i, j);
        const pairs = (tl === 1)
          ? [[dirOf.up, dirOf.left], [dirOf.down, dirOf.right]]
          : [[dirOf.up, dirOf.right], [dirOf.left, dirOf.down]];
        for (const [a, b] of pairs) {
          if (a === undefined || b === undefined) continue;
          nextOf.set(a + '@' + key, b);
          nextOf.set(b + '@' + key, a);
        }
      }
    }

    const used = new Uint8Array(segs.length);
    const loops = [];
    for (let i = 0; i < segs.length; i++) {
      if (used[i]) continue;
      const loop = [];
      let cur = i;
      const startKey = segs[i][0] + ',' + segs[i][1];
      let curKey = startKey;
      let guard = 0;
      while (guard++ < segs.length * 2 + 4) {
        if (used[cur]) break;
        used[cur] = 1;
        const s = segs[cur];
        const k1 = s[0] + ',' + s[1], k2 = s[2] + ',' + s[3];
        const otherKey = (k1 === curKey) ? k2 : k1;
        const comma = otherKey.indexOf(',');
        loop.push([parseFloat(otherKey.slice(0, comma)), parseFloat(otherKey.slice(comma + 1))]);
        if (otherKey === startKey) break;
        cur = nextOf.get(cur + '@' + otherKey);
        if (cur === undefined) break;
        curKey = otherKey;
      }
      if (loop.length >= 3) loops.push(loop);
    }
    return loops;
  }

  /* ---------- 5. Площадь и ориентация контуров ---------- */
  function loopSignedArea(loop) {
    let a = 0;
    for (let i = 0; i < loop.length; i++) {
      const p = loop[i], q = loop[(i + 1) % loop.length];
      a += p[0] * q[1] - q[0] * p[1];
    }
    return a / 2;
  }

  function pointInLoop(x, y, loop) {
    let inside = false;
    for (let i = 0, j = loop.length - 1; i < loop.length; j = i++) {
      const xi = loop[i][0], yi = loop[i][1], xj = loop[j][0], yj = loop[j][1];
      if ((yi > y) !== (yj > y) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }

  // Внешние контуры — против часовой, дырки — по часовой (для fill-rule="nonzero")
  function orientLoops(loops) {
    const areas = loops.map(loopSignedArea);
    for (let i = 0; i < loops.length; i++) {
      let depth = 0;
      for (let j = 0; j < loops.length; j++) {
        if (i === j) continue;
        if (Math.abs(areas[j]) > Math.abs(areas[i]) &&
            pointInLoop(loops[i][0][0], loops[i][0][1], loops[j])) depth++;
      }
      const wantCCW = (depth % 2 === 0);
      if ((areas[i] > 0) !== wantCCW) loops[i].reverse();
    }
  }

  /* ---------- 6. Упрощение (RDP) и сглаживание ---------- */
  function rdpSimplify(pts, tol) {
    const n = pts.length;
    if (n <= 2) return pts;
    const keep = new Uint8Array(n);
    keep[0] = 1; keep[n - 1] = 1;
    const tol2 = tol * tol;
    const stack = [[0, n - 1]];
    while (stack.length) {
      const pair = stack.pop();
      const a = pair[0], b = pair[1];
      if (b - a < 2) continue;
      const ax = pts[a][0], ay = pts[a][1];
      const vx = pts[b][0] - ax, vy = pts[b][1] - ay;
      const len2 = vx * vx + vy * vy;
      let maxD2 = -1, idx = -1;
      for (let k = a + 1; k < b; k++) {
        const px = pts[k][0] - ax, py = pts[k][1] - ay;
        let d2;
        if (len2 < 1e-12) d2 = px * px + py * py;
        else {
          const t = (px * vx + py * vy) / len2;
          const qx = px - t * vx, qy = py - t * vy;
          d2 = qx * qx + qy * qy;
        }
        if (d2 > maxD2) { maxD2 = d2; idx = k; }
      }
      if (idx >= 0 && maxD2 > tol2) {
        keep[idx] = 1;
        stack.push([a, idx], [idx, b]);
      }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(pts[i]);
    return out;
  }

  function simplifyLoop(pts, tol) {
    const n = pts.length;
    if (n <= 4) return pts.slice();
    let best = -1, bi = 0;
    for (let i = 1; i < n; i++) {
      const dx = pts[i][0] - pts[0][0], dy = pts[i][1] - pts[0][1];
      const d = dx * dx + dy * dy;
      if (d > best) { best = d; bi = i; }
    }
    if (best < 0) return pts.slice();
    const open = [];
    for (let k = 0; k <= n; k++) open.push(pts[(bi + k) % n]);
    const res = rdpSimplify(open, tol);
    res.pop();
    return res;
  }

  // Адаптивное упрощение по кривизне (принцип Adobe Illustrator):
  // порог RDP в каждой точке зависит от локальной кривизны — на изгибах порог
  // маленький (точки сохраняются), на прямых — большой (точки убираются).
  // Результат: максимум точек на деталях, минимум на прямых линиях.
  function adaptiveSimplify(pts, tol) {
    const n = pts.length;
    if (n <= 6) return pts.slice();

    // локальная кривизна каждой точки: |поворот| / (длина окрестности)
    const curv = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const a = pts[(i - 1 + n) % n], b = pts[i], c = pts[(i + 1) % n];
      const ax = b[0] - a[0], ay = b[1] - a[1];
      const bx = c[0] - b[0], by = c[1] - b[1];
      const la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
      if (la < 1e-6 || lb < 1e-6) { curv[i] = 1; continue; }
      let dot = (ax * bx + ay * by) / (la * lb);
      dot = Math.max(-1, Math.min(1, dot));
      const ang = Math.acos(dot);               // 0 = прямо, π = острый пик
      curv[i] = Math.min(1, ang / Math.PI * 2) * Math.min(la, lb);
    }
    // эффективный порог: на изгибах (curv велика) — меньше допуск
    const effTol = (i) => tol * (1.6 - Math.min(1.2, curv[i] * 0.5));

    // RDP с переменным порогом: разворачиваем замкнутый контур от самой
    // удалённой точки (максимум деталей сохраняется на изгибах)
    let best = -1, bi = 0;
    for (let i = 1; i < n; i++) {
      const dx = pts[i][0] - pts[0][0], dy = pts[i][1] - pts[0][1];
      const d = dx * dx + dy * dy;
      if (d > best) { best = d; bi = i; }
    }
    if (best < 0) return pts.slice();
    const open = [];
    const idx = [];
    for (let k = 0; k <= n; k++) { open.push(pts[(bi + k) % n]); idx.push((bi + k) % n); }
    const keep = new Uint8Array(n);
    keep[0] = 1; keep[n - 1] = 1; keep[idx[n]] = 1; keep[idx[0]] = 1;
    const stack = [[0, n]];
    while (stack.length) {
      const pair = stack.pop();
      const a = pair[0], b = pair[1];
      if (b - a < 2) continue;
      const ax = open[a][0], ay = open[a][1];
      const vx = open[b][0] - ax, vy = open[b][1] - ay;
      const len2 = vx * vx + vy * vy;
      let maxD = -1, mIdx = -1;
      for (let k = a + 1; k < b; k++) {
        const px = open[k][0] - ax, py = open[k][1] - ay;
        let d;
        if (len2 < 1e-12) d = Math.hypot(px, py);
        else {
          const tt = (px * vx + py * vy) / len2;
          const qx = px - tt * vx, qy = py - tt * vy;
          d = Math.hypot(qx, qy);
        }
        // сравниваем с АДАПТИВНЫМ порогом точки k
        if (d > maxD && d > effTol(idx[k])) { maxD = d; mIdx = k; }
      }
      if (mIdx >= 0) {
        keep[idx[mIdx]] = 1;
        stack.push([a, mIdx], [mIdx, b]);
      }
    }
    const out = [];
    for (let i = 0; i < n; i++) if (keep[i]) out.push(pts[i]);
    return out.length >= 3 ? out : pts.slice();
  }

  // RDP для замкнутого контура: разворачиваем в открытую цепочку от самой удалённой точки
  function rdpClosed(pts, tol) {
    let best = -1, bi = 0;
    for (let i = 1; i < pts.length; i++) {
      const dx = pts[i][0] - pts[0][0], dy = pts[i][1] - pts[0][1];
      const d = dx * dx + dy * dy;
      if (d > best) { best = d; bi = i; }
    }
    if (best < 0) return pts.slice();
    const open = [];
    for (let k = 0; k <= pts.length; k++) open.push(pts[(bi + k) % pts.length]);
    const res = rdpSimplify(open, tol);
    res.pop();
    return res;
  }

  const fmt = (v) => String(Math.round(v * 100) / 100);

  // Контур -> path data. smoothing 0..100 — скругление углов кривыми Безье.
  // Сглаживание УГЛОЗАВИСИМОЕ: чем острее угол между сегментами, тем меньше
  // радиус скругления (острые пики сохраняются, плавные изгибы сглаживаются).
  // Контур -> path data. Классическое скругление углов (как Potrace):
  //   - вершина НЕ удаляется, её «плечи» скругляются кривой Безье;
  //   - радиус зависит от остроты угла: острый излом (>=~100°) остаётся углом,
  //     прямой скругляется умеренно, плавный — сильно (без лесенки);
  //   - точки на границе изображения всегда углы (чёткий прямоугольник);
  //   - smoothing 0 = полилиния, 100 = максимальное скругление.
  function loopToPathData(loop, smoothing, w, h) {
    const n = loop.length;
    if (n < 2) return '';
    const f = clamp(smoothing / 100, 0, 1);
    const P = (i) => loop[((i % n) + n) % n];
    const onBorder = (x, y) => (w !== undefined && h !== undefined) &&
      (x <= 0.5 || y <= 0.5 || x >= w - 0.5 || y >= h - 0.5);

    // без сглаживания — полилиния
    if (f < 0.02) {
      let d = 'M' + fmt(P(0)[0]) + ' ' + fmt(P(0)[1]);
      for (let i = 1; i < n; i++) d += 'L' + fmt(P(i)[0]) + ' ' + fmt(P(i)[1]);
      return d + 'Z';
    }

    // резкость излома (0 = прямая, 1 = острый пик 0°)
    const sharp = [];
    for (let i = 0; i < n; i++) {
      const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1);
      const ax = p1[0] - p0[0], ay = p1[1] - p0[1];
      const bx = p2[0] - p1[0], by = p2[1] - p1[1];
      const la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
      let dot = 0;
      if (la > 1e-6 && lb > 1e-6) dot = (ax * bx + ay * by) / (la * lb);
      sharp[i] = clamp((1 - dot) * 0.5, 0, 1);
    }
    const SHARP_LIMIT = 0.62; // поворот >= ~100° → острый угол, без скругления

    const parts = [];
    for (let i = 0; i < n; i++) {
      const p1 = P(i);
      if (onBorder(p1[0], p1[1]) || sharp[i] >= SHARP_LIMIT) {
        parts.push({ t: 'P', x: p1[0], y: p1[1] });   // угол
        continue;
      }
      const p0 = P(i - 1), p2 = P(i + 1);
      const ax = p1[0] - p0[0], ay = p1[1] - p0[1];
      const bx = p2[0] - p1[0], by = p2[1] - p1[1];
      const la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
      // радиус скругления: гладкие (sharp→0) — максимальный, острые — меньше
      const r = f * Math.min(la, lb) * (1 - sharp[i] * 0.6);
      if (la < 1e-6 || lb < 1e-6 || r < 0.4) {
        parts.push({ t: 'P', x: p1[0], y: p1[1] });
      } else {
        parts.push({
          t: 'A',
          sx: p1[0] - ax / la * r, sy: p1[1] - ay / la * r,
          cx: p1[0], cy: p1[1],
          ex: p1[0] + bx / lb * r, ey: p1[1] + by / lb * r
        });
      }
    }

    let d = '';
    const add = (s) => { if (d) d += ' '; d += s; };
    const same = (x1, y1, x2, y2) => Math.abs(x1 - x2) < 1e-4 && Math.abs(y1 - y2) < 1e-4;
    const first = parts[0];
    let cx, cy;
    if (first.t === 'A') { cx = first.sx; cy = first.sy; }
    else { cx = first.x; cy = first.y; }
    add('M' + fmt(cx) + ' ' + fmt(cy));
    for (let i = 0; i < n; i++) {
      const p = parts[i];
      if (p.t === 'P') {
        if (!same(cx, cy, p.x, p.y)) { add('L' + fmt(p.x) + ' ' + fmt(p.y)); cx = p.x; cy = p.y; }
      } else {
        if (!same(cx, cy, p.sx, p.sy)) { add('L' + fmt(p.sx) + ' ' + fmt(p.sy)); }
        const c1x = cx + (p.cx - cx) * 2 / 3, c1y = cy + (p.cy - cy) * 2 / 3;
        const c2x = p.ex + (p.cx - p.ex) * 2 / 3, c2y = p.ey + (p.cy - p.ey) * 2 / 3;
        add('C' + fmt(c1x) + ' ' + fmt(c1y) + ' ' + fmt(c2x) + ' ' + fmt(c2y) + ' ' + fmt(p.ex) + ' ' + fmt(p.ey));
        cx = p.ex; cy = p.ey;
      }
    }
    add('Z');
    return d;
  }

  /* ---------- 7. Квантование цветов: сначала сильно отличающиеся, потом оттенки ---------- */
  // Алгоритм: farthest-point sampling + k-means.
  //   1) первый цвет — самый частый (доминирующий);
  //   2) каждый следующий — цвет, МАКСИМАЛЬНО отличающийся от уже выбранных;
  //   3) при увеличении количества цветов добавляются оттенки уже выбранных.
  // Это даёт требуемое поведение: розовый + голубой выбираются первыми,
  // а не 8 оттенков розового.
  function colorDist8(c1, c2) {
    const dr = c1.r - c2.r, dg = c1.g - c2.g, db = c1.b - c2.b;
    return dr * dr + dg * dg + db * db;
  }

  function quantizeMasks(image, nColors) {
    const { data, width: w, height: h } = image;
    const hist = new Int32Array(1 << 15);
    const hidx = (r, g, b) => (r << 10) | (g << 5) | b;
    let distinct = 0;
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 128) continue;
      const v = hidx(data[i] >> 3, data[i + 1] >> 3, data[i + 2] >> 3);
      if (hist[v]++ === 0) distinct++;
    }

    // список уникальных цветов с весами (в 8-бит)
    const colors = [];
    for (let v = 0; v < hist.length; v++) {
      if (hist[v]) {
        colors.push({
          r: ((v >> 10) & 31) << 3,
          g: ((v >> 5) & 31) << 3,
          b: (v & 31) << 3,
          w: hist[v]
        });
      }
    }
    if (!colors.length) {
      return { palette: [[255, 255, 255]], masks: [new Uint8Array(w * h)] };
    }

    const k = Math.max(1, Math.min(nColors, colors.length));

    // farthest point sampling
    const centers = [];
    let first = 0;
    for (let i = 1; i < colors.length; i++) if (colors[i].w > colors[first].w) first = i;
    centers.push(colors[first]);
    const distTo = new Float32Array(colors.length);
    for (let i = 0; i < colors.length; i++) distTo[i] = colorDist8(colors[i], colors[first]);
    while (centers.length < k) {
      let best = -1, bestD = -1;
      for (let i = 0; i < colors.length; i++) {
        if (distTo[i] > bestD) { bestD = distTo[i]; best = i; }
      }
      if (best < 0 || bestD <= 0) break;
      centers.push(colors[best]);
      for (let i = 0; i < colors.length; i++) {
        const d = colorDist8(colors[i], colors[best]);
        if (d < distTo[i]) distTo[i] = d;
      }
    }

    // k-means уточнение
    const assignment = new Int32Array(colors.length);
    for (let iter = 0; iter < 8; iter++) {
      for (let i = 0; i < colors.length; i++) {
        let bj = 0, bd = Infinity;
        for (let j = 0; j < centers.length; j++) {
          const d = colorDist8(colors[i], centers[j]);
          if (d < bd) { bd = d; bj = j; }
        }
        assignment[i] = bj;
      }
      const sums = centers.map(() => ({ r: 0, g: 0, b: 0, w: 0 }));
      for (let i = 0; i < colors.length; i++) {
        const s = sums[assignment[i]];
        s.r += colors[i].r * colors[i].w;
        s.g += colors[i].g * colors[i].w;
        s.b += colors[i].b * colors[i].w;
        s.w += colors[i].w;
      }
      for (let j = 0; j < centers.length; j++) {
        if (sums[j].w > 0) {
          centers[j] = { r: Math.round(sums[j].r / sums[j].w), g: Math.round(sums[j].g / sums[j].w), b: Math.round(sums[j].b / sums[j].w) };
        }
      }
    }

    const palette = centers.map((c) => [c.r, c.g, c.b]);
    const masks = palette.map(() => new Uint8Array(w * h));
    for (let p = 0, i = 0; p < w * h; p++, i += 4) {
      if (data[i + 3] < 128) continue;
      let bj = 0, bd = Infinity;
      for (let j = 0; j < palette.length; j++) {
        const dr = data[i] - palette[j][0], dg = data[i + 1] - palette[j][1], db = data[i + 2] - palette[j][2];
        const d = dr * dr + dg * dg + db * db;
        if (d < bd) { bd = d; bj = j; }
      }
      masks[bj][p] = 1;
    }
    return { palette, masks };
  }

  /* ---------- 8. Полные пайплайны ---------- */

  // Ч/Б трассировка. Возвращает [{d, fill}]
  // points (0-100) — «количество точек»: чем больше, тем меньше упрощение (больше точек).
  // Мелкие объекты автоматически получают меньше точек (короткий периметр → RDP оставляет мало).
  function traceBW(image, minT, maxT, invert, smoothing, points) {
    const w = image.width, h = image.height;
    let mask = thresholdBW(image, minT, maxT, invert);
    mask = removeSmallComponents(mask, w, h, 3);
    let loops = traceContours(mask, w, h);
    loops = loops.filter((l) => Math.abs(loopSignedArea(l)) >= 0.75);
    if (!loops.length) return [];
    orientLoops(loops);
    // tol уменьшается с ростом points → больше точек сохраняется.
    // Минимум 0.8: пиксельная ступенька (сдвиг 1px) имеет отклонение ~0.71,
    // поэтому при tol >= 0.8 лесенка схлопывается в диагональ — детали
    // уточняются, но «лесенки» не появляется при любом points.
    const p = (points === undefined || points === null) ? 50 : clamp(points, 0, 100);
    const tol = 2.9 - (p / 100) * 2.1; // 100 → 0.8 (максимум деталей), 0 → 2.9 (мало точек)
    const paths = [];
    let d = '', cnt = 0;
    const flush = () => { if (d) { paths.push(d); d = ''; cnt = 0; } };
    for (const l of loops) {
      d += (d ? ' ' : '') + loopToPathData(simplifyLoop(l, tol), smoothing, w, h);
      if (++cnt >= 1500) flush();
    }
    flush();
    // Инверсия меняет только фигуру (какие пиксели становятся чернилами),
    // а не цвет: фигура всегда чёрная.
    const fill = '#111111';
    return paths.map((p) => ({ d: p, fill }));
  }

  // Цветная трассировка: квантование + послойная трассировка + дилатация для стыков.
  // mode: 'simple' — равномерное упрощение; 'adaptive' — больше точек на изгибах,
  // минимум на прямых (адаптивное упрощение).
  function traceColor(image, nColors, smoothing, points, mode, overlap) {
    const { palette, masks } = quantizeMasks(image, nColors);
    const w = image.width, h = image.height;
    const out = [];
    const coverages = [];
    // overlap — «стыковка цветов»: сколько пикселей контур каждого цвета
    // заходит на соседний (0 = точно по границе, 2 = стандарт, 4 = макс.
    // перекрытие). Регулирует толщину стыков.
    const ov = (overlap === undefined || overlap === null) ? 2 : Math.max(0, Math.min(4, Math.round(overlap)));
    for (let k = 0; k < masks.length; k++) {
      let mask = removeSmallComponents(masks[k], w, h, 3);
      let cov = 0;
      for (let p = 0; p < mask.length; p++) cov += mask[p];
      if (cov < 2) continue;
      // сглаживаем уголки маски → гладкие диагонали.
      // Дилатация = overlap px: контуры соседних цветов перекрываются,
      // на стыках не остаётся белых проплешин
      let maskS = smoothMaskCorners(mask, w, h);
      let maskD = maskS;
      for (let d = 0; d < ov; d++) maskD = dilate(maskD, w, h);
      let loops = traceContours(maskD, w, h);
      loops = loops.filter((l) => Math.abs(loopSignedArea(l)) >= 0.75);
      if (!loops.length) continue;
      orientLoops(loops);
      const p = (points === undefined || points === null) ? 50 : clamp(points, 0, 100);
      const adaptive = mode === 'adaptive';
      const chunks = [];
      let d = '', cnt = 0;
      for (const l of loops) {
        let simp;
        if (adaptive) {
          // Adaptive (как Illustrator): порог зависит от кривизны —
          // много точек на изгибах, минимум на прямых
          const baseTol = 1.0 + (1 - p / 100) * 2.0;
          simp = adaptiveSimplify(l, baseTol);
        } else {
          // Simple (классика): равномерное RDP-упрощение.
          // tol = 0.75 при 100 (детально, пиксельные ступеньки схлопываются),
          // tol = 2.75 при 0 (максимально гладко)
          const tol = 0.75 + (1 - p / 100) * 2.0;
          simp = simplifyLoop(l, tol);
        }
        d += (d ? ' ' : '') + loopToPathData(simp, smoothing, w, h);
        if (++cnt >= 1500) { chunks.push(d); d = ''; cnt = 0; }
      }
      if (d) chunks.push(d);
      const fill = 'rgb(' + palette[k][0] + ',' + palette[k][1] + ',' + palette[k][2] + ')';
      for (const ch of chunks) { out.push({ d: ch, fill }); coverages.push(cov); }
    }
    // крупные области рисуем первыми, мелкие — поверх (скрывают швы)
    const order = out.map((_, i) => i).sort((a, b) => coverages[b] - coverages[a]);
    const sorted = order.map((i) => out[i]);
    // гарантия отсутствия проплешин: заливаем весь холст цветом самого
    // большого слоя. Фон кладём ПЕРВЫМ (вниз стека) — остальные цвета
    // рисуются поверх него, а не наоборот (иначе фон перекрыл бы картинку)
    if (sorted.length) {
      sorted.unshift({ d: 'M0 0H' + w + 'V' + h + 'H0Z', fill: sorted[0].fill });
    }
    return sorted;
  }

  /* ---------- 9. Halftone ---------- */
  // Bootstrap heart: M8 1.314 C12.438 -3.248 23.534 4.735 8 15 C-7.534 4.736 3.562 -3.248 8 1.314 Z
  // bbox: x -7.534..23.534 (31.068), y -3.248..15 (18.248)
  const HEART_TEMPLATE = 'M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z';
  const HEART_CX = 8, HEART_CY = 5.876, HEART_W = 31.068;

  function transformTemplate(tpl, cx, cy, s) {
    const tokens = tpl.match(/[a-zA-Z]|-?\d*\.?\d+(?:e[-+]?\d+)?/g) || [];
    let rel = false, isX = true;
    const out = [];
    for (const t of tokens) {
      if (/[a-zA-Z]/.test(t)) {
        rel = /[a-z]/.test(t) && t !== 'z';
        out.push(t); isX = true;
        continue;
      }
      const v = parseFloat(t);
      const nv = rel ? v * s : (isX ? cx + (v - HEART_CX) * s : cy + (v - HEART_CY) * s);
      out.push(fmt(nv));
      isX = !isX;
    }
    let str = '';
    for (const o of out) {
      const isNum = /^-?[\d.]/.test(o);
      if (str && !(isNum && /[a-zA-Z]$/.test(str))) str += ' ';
      str += o;
    }
    return str;
  }

  // Одна точка halftone в виде path-data (без дуг — только линии и кубики Безье)
  // shape: 'circle' | 'cross' | 'heart' | 'star4' | 'star5'
  function dotSubPath(shape, cx, cy, size) {
    const half = size / 2;
    if (shape === 'cross') {
      const wb = size * 0.2;
      return 'M' + fmt(cx - wb) + ' ' + fmt(cy - half) +
        'L' + fmt(cx + wb) + ' ' + fmt(cy - half) +
        'L' + fmt(cx + wb) + ' ' + fmt(cy - wb) +
        'L' + fmt(cx + half) + ' ' + fmt(cy - wb) +
        'L' + fmt(cx + half) + ' ' + fmt(cy + wb) +
        'L' + fmt(cx + wb) + ' ' + fmt(cy + wb) +
        'L' + fmt(cx + wb) + ' ' + fmt(cy + half) +
        'L' + fmt(cx - wb) + ' ' + fmt(cy + half) +
        'L' + fmt(cx - wb) + ' ' + fmt(cy + wb) +
        'L' + fmt(cx - half) + ' ' + fmt(cy + wb) +
        'L' + fmt(cx - half) + ' ' + fmt(cy - wb) +
        'L' + fmt(cx - wb) + ' ' + fmt(cy - wb) + 'Z';
    }
    if (shape === 'heart') {
      return transformTemplate(HEART_TEMPLATE, cx, cy, size / HEART_W);
    }
    if (shape === 'star4' || shape === 'star5') {
      return starSubPath(cx, cy, size, shape === 'star4' ? 4 : 5);
    }
    // circle — 4 кубических Безье (без 'a' команд, надёжно везде)
    const r = half;
    const k = 0.5522847498;
    const c1x = cx - r, c1y = cy - k * r, c2x = cx - k * r, c2y = cy - r;
    return 'M' + fmt(cx - r) + ' ' + fmt(cy) +
      'C' + fmt(c1x) + ' ' + fmt(c1y) + ' ' + fmt(c2x) + ' ' + fmt(c2y) + ' ' + fmt(cx) + ' ' + fmt(cy - r) +
      'C' + fmt(cx + k * r) + ' ' + fmt(cy - r) + ' ' + fmt(cx + r) + ' ' + fmt(c1y) + ' ' + fmt(cx + r) + ' ' + fmt(cy) +
      'C' + fmt(cx + r) + ' ' + fmt(cy + k * r) + ' ' + fmt(cx + k * r) + ' ' + fmt(cy + r) + ' ' + fmt(cx) + ' ' + fmt(cy + r) +
      'C' + fmt(cx - k * r) + ' ' + fmt(cy + r) + ' ' + fmt(cx - r) + ' ' + fmt(cy + k * r) + ' ' + fmt(cx - r) + ' ' + fmt(cy) + 'Z';
  }

  // Звезда: points = 4 или 5 концов. Внешние вершины — на окружности радиуса R,
  // внутренние — на радиусе r. 4-конечная: вершины по осям (вертикальная вверх),
  // 5-конечная: верхняя вершина вверх (rot = −90°).
  function starSubPath(cx, cy, size, points) {
    const R = size / 2;
    const r = R * (points === 4 ? 0.35 : 0.45);
    const n = points * 2;
    const rot = -Math.PI / 2;
    let d = '';
    for (let i = 0; i < n; i++) {
      const ang = rot + (i * Math.PI) / points;
      const rad = i % 2 === 0 ? R : r;
      const x = cx + rad * Math.cos(ang);
      const y = cy + rad * Math.sin(ang);
      d += (i === 0 ? 'M' : 'L') + fmt(x) + ' ' + fmt(y);
    }
    return d + 'Z';
  }

  // Halftone. Возвращает [{d, fill}] (чанки по 1200 подпутей) + статистику.
  // threshold (0-255) — порог для ч/б режима: ячейки СВЕТЛЕЕ порога не дают
  // точки вовсе, темнее — дают точку, размер растёт по мере затемнения.
  // В цветном режиме (colorMode) порог не применяется.
  function traceHalftone(image, cell, shape, invert, colorMode, minT, maxT) {
    const { data, width: w, height: h } = image;
    let cols = Math.ceil(w / cell), rows = Math.ceil(h / cell);
    const MAX_DOTS = 30000;
    if (cols * rows > MAX_DOTS) {
      const k = Math.sqrt((cols * rows) / MAX_DOTS);
      cell = cell * k;
      cols = Math.ceil(w / cell); rows = Math.ceil(h / cell);
    }
    const dots = []; // {d, fill}
    const pushDot = (d, fill) => {
      const last = dots[dots.length - 1];
      if (last && last.fill === fill && last.count < 1200) { last.d += ' ' + d; last.count++; }
      else dots.push({ d, fill, count: 1 });
    };
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x0 = Math.floor(c * cell), y0 = Math.floor(r * cell);
        const x1 = Math.min(Math.ceil((c + 1) * cell), w), y1 = Math.min(Math.ceil((r + 1) * cell), h);
        let sum = 0, sr = 0, sg = 0, sb = 0, n = 0, nOpaque = 0;
        for (let y = y0; y < y1; y++) {
          let i = (y * w + x0) * 4;
          for (let x = x0; x < x1; x++, i += 4) {
            if (data[i + 3] < 128) continue; // прозрачные не дают точку
            sum += data[i] * LR + data[i + 1] * LG + data[i + 2] * LB;
            sr += data[i]; sg += data[i + 1]; sb += data[i + 2];
            n++; nOpaque++;
          }
        }
        if (!nOpaque) continue;
        const L = sum / n / 255;
        let t;
        if (colorMode) {
          t = Math.max(0, 1 - L);
        } else if (minT !== undefined && minT !== null) {
          const lo = clamp(minT, 0, 255);
          const hi = (maxT === undefined || maxT === null) ? 128 : clamp(maxT, 0, 255);
          const span = Math.max(1, hi - lo);
          const L255 = L * 255;
          // диапазон [lo, hi]: lo = максимум чернил, hi = ноль
          t = clamp((hi - L255) / span, 0, 1);
          if (invert) t = 1 - t;
        } else {
          t = Math.max(0, 1 - L);
        }
        // размер точки: полностью чёрная ячейка даёт точку, выходящую
        // за границы (коэффициент 1.4) — круги сливаются
        const size = cell * 1.4 * Math.sqrt(t);
        if (size < 1.2) continue;
        const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
        const fill = colorMode
          ? 'rgb(' + Math.round(sr / n) + ',' + Math.round(sg / n) + ',' + Math.round(sb / n) + ')'
          : '#111111'; // ч/б: точки всегда чёрные, инверсия меняет только фигуру
        pushDot(dotSubPath(shape, cx, cy, size), fill);
      }
    }
    return dots;
  }

  /* ---------- 9b. Цветной halftone: CMYK-раскладка ---------- */
  // Четыре печатных канала:
  //   голубой (C) = 1 − R, пурпурный (M) = 1 − G, жёлтый (Y) = 1 − B,
  //   чёрный (K) = min(C, M, Y) — усиливает тени и нейтральные тона.
  // Чернильность каналов проходит гамма-кривую (γ = 1.6) — середина тонов
  // светлеет, контраст смягчается, тени не уходят в черноту.
  // ЧЕМ ТЕМНЕЕ канал — тем больше точка (размер ∝ √чернильности), точка может
  // выходить за рамки ячейки (коэффициент 1.1) и сливаться с соседними.
  // Сетки каналов смещены друг относительно друга на 2–3 пункта (розеточный
  // растр как в печати), чтобы точки не ложились ровно друг на друга.
  // Слои накладываются умножением (multiply) на белой подложке:
  //   M×Y = красный, C×Y = зелёный, C×M = синий, C×M×Y×K = чёрный.
  // Возвращает [{ fill, blend, paths: [{d, count}] }] — по слою на канал.
  function traceHalftoneCMYK(image, cell, shape) {
    const { data, width: w, height: h } = image;
    let cols = Math.ceil(w / cell), rows = Math.ceil(h / cell);
    const MAX_DOTS = 30000;
    if (cols * rows > MAX_DOTS) {
      const k = Math.sqrt((cols * rows) / MAX_DOTS);
      cell = cell * k;
      cols = Math.ceil(w / cell); rows = Math.ceil(h / cell);
    }
    // гамма-кривая смягчает контраст: 1 = линейно, >1 светлее середина тонов
    const GAMMA = 1.25;
    const curve = (v) => Math.pow(v, GAMMA);
    // смещение сеток каналов: C/M/Y — вершины равностороннего треугольника
    // (одинаковое расстояние между каналами), K — точно в центре треугольника
    const off = Math.min(4, Math.max(1.5, cell * 0.3)); // сторона треугольника, 2–3 пункта
    const R = off / Math.sqrt(3); // радиус описанной окружности треугольника
    const OFF = [
      [0, -R],                    // cyan — верхняя вершина
      [R * 0.8660254, R * 0.5],   // magenta — нижняя правая
      [-R * 0.8660254, R * 0.5],  // yellow — нижняя левая
      [0, 0]                      // black — центр треугольника
    ];
    const layers = [
      { fill: '#00ffff', blend: 'multiply', paths: [] }, // cyan
      { fill: '#ff00ff', blend: 'multiply', paths: [] }, // magenta
      { fill: '#ffff00', blend: 'multiply', paths: [] }, // yellow
      { fill: '#000000', blend: 'multiply', paths: [] }  // black (key)
    ];
    const push = (layer, d) => {
      const last = layer.paths[layer.paths.length - 1];
      if (last && last.count < 1200) { last.d += ' ' + d; last.count++; }
      else layer.paths.push({ d, count: 1 });
    };
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x0 = Math.floor(c * cell), y0 = Math.floor(r * cell);
        const x1 = Math.min(Math.ceil((c + 1) * cell), w), y1 = Math.min(Math.ceil((r + 1) * cell), h);
        let sr = 0, sg = 0, sb = 0, n = 0;
        for (let y = y0; y < y1; y++) {
          let i = (y * w + x0) * 4;
          for (let x = x0; x < x1; x++, i += 4) {
            if (data[i + 3] < 128) continue; // прозрачные не дают точку
            sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; n++;
          }
        }
        if (!n) continue;
        const R = sr / n / 255, G = sg / n / 255, B = sb / n / 255;
        const cVal = curve(1 - R), mVal = curve(1 - G), yVal = curve(1 - B);
        // K слабее (0.7) и дополнительно смягчён кривой — только усиливает тени
        const kVal = curve(Math.min(cVal, mVal, yVal) * 0.7);
        const chans = [cVal, mVal, yVal, kVal];
        const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
        for (let k = 0; k < 4; k++) {
          // темнее канал → больше точка
          const size = cell * 1.2 * Math.sqrt(chans[k]);
          if (size < 1.2) continue;
          push(layers[k], dotSubPath(shape, cx + OFF[k][0], cy + OFF[k][1], size));
        }
      }
    }
    return layers;
  }

  /* ---------- 10. ASCII art ---------- */
  const CHARSETS = {
    classic:  '@%#*+=-:. ',
    detailed: '$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\\|()1{}[]?-_+~<>i!lI;:,"^\'`. ',
    minimal:  '#. ',
    blocks:   '\u2588\u2593\u2592\u2591 '
  };

  // asciiArt: чернильность нормируется в диапазоне яркости [minT, maxT]
  function asciiArt(image, cellPx, charsetKey, invert, minT, maxT) {
    const charset = CHARSETS[charsetKey] || CHARSETS.classic;
    const { data, width: w, height: h } = image;
    const cols = Math.max(1, Math.ceil(w / cellPx));
    const rows = Math.max(1, Math.ceil(h / cellPx));
    const lines = [];
    const lastIdx = charset.length - 1;
    const lo = (minT === undefined || minT === null) ? 0 : clamp(minT, 0, 255);
    const hi = (maxT === undefined || maxT === null) ? 128 : clamp(maxT, 0, 255);
    const span = Math.max(1, hi - lo);
    for (let r = 0; r < rows; r++) {
      let line = '';
      const y0 = Math.floor(r * cellPx), y1 = Math.min(Math.ceil((r + 1) * cellPx), h);
      for (let c = 0; c < cols; c++) {
        const x0 = Math.floor(c * cellPx), x1 = Math.min(Math.ceil((c + 1) * cellPx), w);
        let sum = 0, n = 0;
        for (let y = y0; y < y1; y++) {
          let i = (y * w + x0) * 4;
          for (let x = x0; x < x1; x++, i += 4) {
            if (data[i + 3] < 128) continue; // прозрачные → пробел
            sum += data[i] * LR + data[i + 1] * LG + data[i + 2] * LB; n++;
          }
        }
        if (!n) { line += ' '; continue; }
        const L = sum / n / 255;
        const L255 = L * 255;
        // нормируем яркость в диапазон [lo, hi]: lo = максимум чернил, hi = ноль чернил
        let t = clamp((hi - L255) / span, 0, 1); // 1 = тёмный (чернила)
        if (invert) t = 1 - t;
        line += charset[Math.round((1 - t) * lastIdx)];
      }
      lines.push(line);
    }
    return lines.join('\n');
  }

  /* ---------- 11. Парсинг path-данных (для прямого рендера на canvas) ---------- */
  // Поддерживает абсолютные и относительные M/L/C/Z (строчные варианты)
  function parsePathData(d) {
    const cmds = [];
    if (!d) return cmds;
    const re = /([MLCQAZmlcqaz])([^MLCQAZmlcqaz]*)/g;
    let m, cx = 0, cy = 0;
    while ((m = re.exec(d)) !== null) {
      const cmd = m[1];
      const nums = (m[2].match(/-?\d*\.?\d+(?:e[-+]?\d+)?/g) || []).map(Number);
      const isRel = cmd !== cmd.toUpperCase() && cmd.toUpperCase() !== 'Z';
      const C = cmd.toUpperCase();
      if (C === 'M' && nums.length >= 2) {
        cx = isRel ? cx + nums[0] : nums[0];
        cy = isRel ? cy + nums[1] : nums[1];
        cmds.push({ cmd: 'M', x: cx, y: cy });
      } else if (C === 'L' && nums.length >= 2) {
        cx = isRel ? cx + nums[0] : nums[0];
        cy = isRel ? cy + nums[1] : nums[1];
        cmds.push({ cmd: 'L', x: cx, y: cy });
      } else if (C === 'C' && nums.length >= 6) {
        const bx = isRel ? cx : 0, by = isRel ? cy : 0;
        const x1 = bx + nums[0], y1 = by + nums[1];
        const x2 = bx + nums[2], y2 = by + nums[3];
        cx = bx + nums[4]; cy = by + nums[5];
        cmds.push({ cmd: 'C', x1, y1, x2, y2, x: cx, y: cy });
      } else if (C === 'Z') {
        cmds.push({ cmd: 'Z' });
      }
    }
    return cmds;
  }

  /* ---------- 12. Сборка SVG ---------- */
  function scalePathNumbers(d, k) {
    if (k === 1) return d;
    return d.replace(/-?\d*\.?\d+(?:e[-+]?\d+)?/gi, (m) => fmt(parseFloat(m) * k));
  }

  // Масштабирование всех слоёв
  function scaleLayers(layers, k) {
    if (k === 1) return layers;
    return layers.map((l) => ({
      blend: l.blend,
      fill: l.fill, // fill может лежать на уровне слоя (RGB-раскладка)
      paths: l.paths.map((p) => ({ d: scalePathNumbers(p.d, k), fill: p.fill }))
    }));
  }

  // layers: [{blend: 'multiply'|null, paths: [{d, fill}]}], bg: цвет фона или null
  // fill-rule="nonzero": перекрывающиеся подпути СЛИВАЮТСЯ (нужно для halftone —
  // точки выходят за ячейки и пересекаются; при evenodd пересечения вырезались
  // бы дырками и фигуры разваливались). Дырки в трассировке работают за счёт
  // противоположного направления контуров (ориентация задаётся в orientLoops).
  function buildSvg(width, height, layers, bg) {
    let s = '<svg xmlns="http://www.w3.org/2000/svg" width="' + fmt(width) + '" height="' + fmt(height) + '">';
    if (bg) s += '<path d="M0 0H' + fmt(width) + 'V' + fmt(height) + 'H0Z" fill="' + bg + '"/>';
    for (const layer of layers) {
      let inner = '';
      for (const p of layer.paths) {
        const fill = p.fill || layer.fill;
        inner += '<path d="' + p.d + '" fill="' + fill + '" fill-rule="nonzero"/>';
      }
      if (layer.blend) s += '<g style="mix-blend-mode:' + layer.blend + '">' + inner + '</g>';
      else s += inner;
    }
    s += '</svg>';
    return s;
  }

  return {
    thresholdBW, removeSmallComponents, dilate, traceContours,
    loopSignedArea, pointInLoop, orientLoops,
    rdpSimplify, simplifyLoop, loopToPathData,
    quantizeMasks, traceBW, traceColor,
    traceHalftone, traceHalftoneCMYK, dotSubPath, starSubPath, asciiArt, CHARSETS,
    adaptiveSimplify, rdpClosed, smoothMaskCorners,
    scalePathNumbers, scaleLayers, buildSvg, parsePathData, fmt, clamp
  };
});
