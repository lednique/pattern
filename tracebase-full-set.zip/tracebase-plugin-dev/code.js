/* ============================================================================
 * TraceBase — плагин трассировки изображений для Figma (с триалом и покупкой)
 * Песочница Figma: работа с документом. Алгоритмы — в ui.html (UI).
 * ==========================================================================*/
'use strict';

figma.showUI(__html__, { width: 380, height: 640, themeColors: false });

let lastInfo = null; // { node, kind: 'image' | 'fill', hash }

/* ---------- идентификатор пользователя (для лицензий и языка) ---------- */
async function getUserId() {
  try {
    if (figma.currentUser && figma.currentUser.id) {
      return { id: figma.currentUser.id, real: true };
    }
  } catch (e) { /* нет доступа */ }
  let uid = await figma.clientStorage.getAsync('tb_anon_id');
  if (!uid) {
    uid = 'anon-' + Math.random().toString(36).slice(2, 10);
    await figma.clientStorage.setAsync('tb_anon_id', uid);
  }
  return { id: uid, real: false };
}

/* ---------- кэш (язык, триал) через clientStorage ---------- */
async function cacheGet(key) {
  try { return await figma.clientStorage.getAsync('tb_cache_' + key) || null; } catch (e) { return null; }
}
async function cacheSet(key, value) {
  try { await figma.clientStorage.setAsync('tb_cache_' + key, value); } catch (e) { /* ignore */ }
}

/* При documentAccess: "dynamic-page" доступ к PageNode требует loadAsync().
   Вызываем перед любыми операциями со страницей (вставка, selection). */
async function ensurePage() {
  try {
    const page = figma.currentPage;
    if (page && typeof page.loadAsync === 'function') {
      await page.loadAsync();
    }
  } catch (e) { /* если loadAsync недоступен — просто продолжаем */ }
}

/* Найти изображение в выделении: сам Image-узел или заливку IMAGE */
function findImage(node) {
  if (!node) return null;
  if (node.type === 'IMAGE' && node.image) {
    return { node, kind: 'image', hash: null };
  }
  if (Array.isArray(node.fills)) {
    for (const f of node.fills) {
      if (f.type === 'IMAGE' && f.imageHash) return { node, kind: 'fill', hash: f.imageHash };
    }
  }
  if ('children' in node && node.children) {
    for (const c of node.children) {
      const r = findImage(c);
      if (r) return r;
    }
  }
  return null;
}

/* Сырые байты изображения (оригинальное разрешение) */
async function getBytes(info) {
  try {
    if (info.kind === 'image' && info.node.image) {
      return await info.node.image.getBytesAsync();
    }
    if (info.hash) {
      return await figma.getImageByHash(info.hash).getBytesAsync();
    }
    throw new Error('no-hash');
  } catch (err) {
    return await info.node.exportAsync({ format: 'PNG' });
  }
}

async function sendSelection() {
  try {
    await ensurePage();
  } catch (e) { /* ignore */ }
  let sel = [];
  try {
    sel = figma.currentPage.selection;
  } catch (e) { sel = []; }
  const info = (sel.length === 1) ? findImage(sel[0]) : null;
  if (info) {
    lastInfo = info;
    figma.ui.postMessage({
      type: 'selection',
      has: true,
      name: info.node.name,
      w: info.node.width,
      h: info.node.height,
      kind: info.kind
    });
  } else {
    lastInfo = null;
    figma.ui.postMessage({ type: 'selection', has: false });
  }
}

figma.on('selectionchange', sendSelection);

/* Моноширинный шрифт для ASCII-режима */
async function pickMonoFont() {
  try {
    const fonts = await figma.listAvailableFontsAsync();
    const wanted = [
      'JetBrains Mono', 'Roboto Mono', 'IBM Plex Mono', 'Fira Code',
      'Courier New', 'Menlo', 'Consolas', 'Monaco', 'PT Mono', 'Source Code Pro'
    ];
    let f = fonts.find((x) => wanted.indexOf(x.fontName.family) !== -1);
    if (!f) f = fonts.find((x) => /mono|courier|console/i.test(x.fontName.family));
    if (!f) f = fonts.find((x) => x.fontName.family === 'Inter') || fonts[0];
    return f ? f.fontName.family : 'Courier New';
  } catch (err) {
    return 'Courier New';
  }
}

function absPos(node) {
  const t = node.absoluteTransform;
  return [t[0][2], t[1][2]];
}

figma.ui.onmessage = async (msg) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'get-user') {
    const u = await getUserId();
    figma.ui.postMessage({ type: 'user', id: u.id, real: u.real });
  } else if (msg.type === 'cache-get') {
    const value = await cacheGet(msg.key);
    figma.ui.postMessage({ type: 'cache-get', key: msg.key, value });
  } else if (msg.type === 'cache-set') {
    await cacheSet(msg.key, msg.value);
  } else if (msg.type === 'open-url') {
    try {
      figma.openExternal(msg.url);
    } catch (e) { /* ignore */ }
  } else if (msg.type === 'ui-resize') {
    const h = Math.max(420, Math.min(980, Math.round(Number(msg.h) || 640)));
    figma.ui.resize(380, h);
  } else if (msg.type === 'request-image') {
    if (!lastInfo) {
      figma.ui.postMessage({ type: 'error', message: 'no-image' });
      return;
    }
    try {
      const bytes = await getBytes(lastInfo);
      figma.ui.postMessage({
        type: 'image',
        bytes,
        targetW: lastInfo.node.width,
        targetH: lastInfo.node.height,
        name: lastInfo.node.name
      });
    } catch (err) {
      figma.ui.postMessage({ type: 'error', message: (err.message || err) });
    }
  } else if (msg.type === 'get-font') {
    const family = await pickMonoFont();
    figma.ui.postMessage({ type: 'font', family });
  } else if (msg.type === 'insert-svg') {
    try {
      await ensurePage();
      const frame = figma.createNodeFromSvg(msg.svg);
      frame.name = (msg.name || 'vector') + ' · trace';
      if (lastInfo) {
        const [x, y] = absPos(lastInfo.node);
        frame.x = x;
        frame.y = y;
      }
      figma.currentPage.selection = [frame];
      figma.viewport.scrollAndZoomIntoView([frame]);
      figma.ui.postMessage({ type: 'inserted', message: 'ok' });
    } catch (err) {
      figma.ui.postMessage({ type: 'error', message: 'insert-failed: ' + (err.message || err) });
    }
  } else if (msg.type === 'insert-ascii') {
    try {
      await ensurePage();
      const family = (msg.family && typeof msg.family === 'string') ? msg.family : 'Courier New';
      let fontName = { family, style: 'Regular' };
      try {
        await figma.loadFontAsync(fontName);
      } catch (e) {
        const fonts = await figma.listAvailableFontsAsync();
        const alt = fonts.find((f) => f.fontName.family === family);
        if (!alt) throw e;
        fontName = alt.fontName;
      }
      const text = figma.createText();
      text.fontName = fontName;
      text.characters = msg.text;
      text.fontSize = msg.fontSize;
      text.lineHeight = { value: msg.fontSize * 0.6, unit: 'PIXELS' };
      text.letterSpacing = { value: 0, unit: 'PIXELS' };
      text.textAutoResize = 'WIDTH_AND_HEIGHT';
      text.fills = [{ type: 'SOLID', color: msg.invert ? { r: 1, g: 1, b: 1 } : { r: 0.07, g: 0.07, b: 0.07 } }];
      text.name = (msg.name || 'ascii') + ' · ASCII';
      if (lastInfo) {
        const [x, y] = absPos(lastInfo.node);
        text.x = x;
        text.y = y;
      }
      figma.currentPage.selection = [text];
      figma.viewport.scrollAndZoomIntoView([text]);
      figma.ui.postMessage({ type: 'inserted', message: 'ok' });
    } catch (err) {
      figma.ui.postMessage({ type: 'error', message: 'insert-failed: ' + (err.message || err) });
    }
  }
};

sendSelection();
