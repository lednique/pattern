#!/usr/bin/env node
/* Харнесс TraceBase: i18n (7 языков, привязка к пользователю), тёмная тема,
   логотип, шрифт, звезда-тумблер, триал 5, кнопка покупки.
   Запуск: node test/tracebase-harness.js */
'use strict';
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('ui.html', 'utf8');
let script = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1])[0];
script = script.replace(/https:\/\/tb-license\.lednique\.ru/g, 'http://localhost:3000');

/* ---------- фейковый DOM ---------- */
const els = {};
function makeEl(id) {
  const el = {
    id, style: { setProperty() {} },
    classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } },
    dataset: {}, value: '', checked: false, disabled: false, textContent: '', innerHTML: '',
    _children: null,
    appendChild(c) { (this._children = this._children || []).push(c); if (this.innerHTML === '') this.innerHTML = '<children>'; },
    _ls: {}, addEventListener(t, cb) { (this._ls[t] = this._ls[t] || []).push(cb); },
    dispatch(t, ev) { for (const cb of this._ls[t] || []) cb(ev || { target: this }); },
    closest() { return null; }
  };
  els[id] = el;
  return el;
}
const NEEDED = ['langBtn','langFlag','langCode','langMenu','licBadge','licCard','lockTitle','lockText','buyBtn','licKey','licActivateBtn','licMsg','mainCard','mainCard2','insertBtn','modeSeg','cardHt','cardBw','cardColor','cardAscii','status','pv','pvEmpty','spinner','selName','selSize','thrMin','thrMax','thrOut','bwSmooth','bwSmoothOut','bwPoints','bwPointsOut','bwInvert','colors','colorsOut','cSmooth','cSmoothOut','cPoints','cPointsOut','fs','fsOut','thrAsciiMin','thrAsciiMax','thrAsciiOut','charset','asciiInvert','htOn','htBody','htColorRow','htColorSeg','htCell','htCellOut','htThrMin','htThrMax','htThrOut','htThrRow','colorModeSeg','qualitySeg','shapeSeg','starSwitch','starKnob','zoom','zoomOut','pvNa'];
for (const id of NEEDED) makeEl(id);
// pvNa: скрыт по умолчанию + переводится
els.pvNa.classList.add('hidden');
els.pvNa.dataset.i18n = 'ht_preview_na';
// data-i18n для проверки перевода
els.insertBtn.dataset.i18n = 'insert';
els.selName.dataset.i18n = 'select_empty';
els.selSize.dataset.i18n = 'select_hint';
els.pvEmpty.dataset.i18n = 'select_hint';
els.lockTitle.dataset.i18n = 'locked_title';
els.starSwitch.closest = (s) => (s === '#starSwitch' ? els.starSwitch : null);
els.pv.width = 332; els.pv.height = 186;
els.pv.getContext = () => ({ clearRect() {}, save() {}, restore() {}, translate() {}, scale() {}, fillRect() {}, fillText() {}, beginPath() {}, moveTo() {}, lineTo() {}, bezierCurveTo() {}, closePath() {}, fill() {}, set fillStyle(v) {}, get fillStyle() { return '#000'; }, set globalCompositeOperation(v) {} });
els.thrMin.value = '0'; els.thrMax.value = '128';
els.thrMin.parentElement = { style: { setProperty() {} } };
els.thrMax.parentElement = els.thrMin.parentElement;
els.thrAsciiMin.parentElement = els.thrMin.parentElement;
els.thrAsciiMax.parentElement = els.thrMin.parentElement;
els.htThrMin.parentElement = els.thrMin.parentElement;
els.htThrMax.parentElement = els.thrMin.parentElement; els.thrOut = makeEl('thrOut');
els.thrAsciiMin.value = '0'; els.thrAsciiMax.value = '128'; els.htThrMin.value = '0'; els.htThrMax.value = '128';
els.bwSmooth.value = '55'; els.colors.value = '12'; els.cSmooth.value = '45';
els.fs.value = '10'; els.htCell.value = '8';
els.zoom.value = '100'; els.bwPoints.value = '50'; els.cPoints.value = '50';
els.charset.value = 'classic';
els.charset._children = ['classic','detailed','minimal','blocks'].map((v) => ({ value: v, textContent: '', dataset: { i18n: 'charset_' + v } }));
els.modeSeg._children = ['bw','color','ascii'].map((m) => { const b = { tagName: 'BUTTON', dataset: { mode: m, i18n: 'mode_' + m }, classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, closest: (s) => (s === 'button' ? b : null) }; return b; });
// qualitySeg: Low / Standard / High (стандарт активен по умолчанию)
els.qualitySeg._children = ['low','standard','high'].map((q) => { const b = { tagName: 'BUTTON', dataset: { quality: q, i18n: 'quality_' + q }, classList: { _s: new Set(q === 'standard' ? ['active'] : []), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, closest: (s) => (s === 'button' ? b : null) }; return b; });
// shapeSeg: circle, cross, heart, star (starBtn)
function segBtn(tag, key, val) {
  const b = { tagName: tag, dataset: {}, classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, _ls: {}, addEventListener() {}, closest: (s) => (s === 'button' ? b : s === '#starSwitch' ? null : null) };
  b.dataset[key] = val;
  return b;
}
els.shapeSeg._children = [
  segBtn('BUTTON','shape','circle'),
  segBtn('BUTTON','shape','cross'),
  segBtn('BUTTON','shape','heart'),
  segBtn('BUTTON','shape','star')
];

const document = {
  getElementById: (id) => els[id] || makeEl(id),
  createElement: (tag) => (tag === 'button' ? { innerHTML: '', dataset: {}, classList: { add() {}, toggle() {}, remove() {} }, addEventListener() {} } : { style: {}, getContext: () => ({}) }),
  querySelector: (sel) => (sel === '.starBtn' ? els.shapeSeg._children[3] : sel === '.licCard .note' ? els.licNote || (els.licNote = makeEl('licNote')) : null),
  querySelectorAll: (sel) => {
    const m = sel.match(/^#([\w-]+)\s+(\w+)$/);
    if (m) {
      const root = els[m[1]];
      return root && root._children ? root._children.filter((c) => (c.tagName || '').toLowerCase() === m[2]) : [];
    }
    if (sel === 'select option[data-i18n]') return els.charset._children;
    if (sel === '#langMenu button') return (els.langMenu._children || []).filter((c) => c.tagName === 'BUTTON');
    if (sel === '[data-i18n]') {
      const arr = els.modeSeg._children.slice();
      arr.push(els.insertBtn, els.selName, els.selSize, els.pvEmpty, els.lockTitle, els.pvNa);
      return arr;
    }
    return [];
  },
  addEventListener() {},
  body: { classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, f) { const on = f !== undefined ? !!f : !this._s.has(c); if (on) this._s.add(c); else this._s.delete(c); return on; }, contains(c) { return this._s.has(c); } }, scrollHeight: 700 }
};

/* ---------- среда ---------- */
const cache = {};
const sent = [];
let msgHandlers = [];
const USER = 'tb-user-' + Date.now();
const sandbox = {
  console, setTimeout, clearTimeout, setInterval, clearInterval,
  Uint8Array, Uint8ClampedArray, Int32Array, Float32Array, Array, Math, JSON, Number, String, Object, Map, Set, Promise, URL: { createObjectURL: () => 'blob:x', revokeObjectURL: () => {} },
  document,
  parent: {
    postMessage: (m) => {
      sent.push(m);
      const pm = m.pluginMessage;
      setTimeout(() => {
        if (pm.type === 'get-user') emit({ data: { pluginMessage: { type: 'user', id: USER, real: true } } });
        else if (pm.type === 'cache-get') emit({ data: { pluginMessage: { type: 'cache-get', key: pm.key, value: cache[pm.key] !== undefined ? cache[pm.key] : null } } });
        else if (pm.type === 'cache-set') cache[pm.key] = pm.value;
      }, 0);
    }
  },
  addEventListener: (t, cb) => msgHandlers.push(cb),
  removeEventListener: () => {},
  fetch: async (url, opts) => {
    const body = JSON.parse((opts && opts.body) || '{}');
    if (String(url).includes('/api/activate-key')) {
      if (body.key === 'AAAA-BBBB-CCCC-DDDD') return { ok: true, json: async () => ({ ok: true, tier: 'deluxe' }) };
      if (body.key === 'BBBB-CCCC-DDDD-EEEE') return { ok: true, json: async () => ({ ok: true, tier: 'basic' }) };
      if (body.key === 'CCCC-DDDD-EEEE-FFFF') return { ok: true, json: async () => ({ ok: false, error: 'bound' }) };
      return { ok: true, json: async () => ({ ok: false, error: 'not_found' }) };
    }
    return { ok: false, json: async () => ({}) };
  },
  window: null
};
sandbox.window = sandbox;
function emit(msg) { for (const cb of msgHandlers) cb(msg); if (sandbox.onmessage) sandbox.onmessage(msg); }
sandbox.Image = class { set src(v) {} };

vm.createContext(sandbox);
vm.runInContext(script, sandbox, { filename: 'ui.html' });
vm.runInContext('globalThis.__api = { lic, licRefresh, licConsume, setLang, LANG: () => LANG, t, state, updateStarToggle };', sandbox);
const api = sandbox.__api;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };

async function runAll() {
  await wait(600);
  /* --- старт: язык по умолчанию английский --- */
  ok(api.LANG() === 'en', 'язык по умолчанию: English');
  ok(els.langFlag.textContent === '🇬🇧', 'флаг 🇬🇧 в кнопке');
  ok(els.modeSeg._children[0].textContent === 'B/W', 'режимы на английском: B/W');
  ok(els.insertBtn.textContent === 'Insert into Figma', 'кнопка вставки: Insert into Figma');
  ok(els.licBadge.innerHTML.includes('5/5'), 'счётчик 5/5');

  /* --- качество цветной трассировки --- */
  ok(api.state.quality === 'standard', 'качество по умолчанию: standard');
  ok(els.qualitySeg._children[1].classList.contains('active'), 'кнопка Standard активна');
  ok(vm.runInContext('qualityMax()', sandbox) === 1024, 'standard → потолок 1024 px');
  els.qualitySeg.dispatch('click', { target: els.qualitySeg._children[0] });
  ok(api.state.quality === 'low', 'клик Low → quality=low');
  ok(els.qualitySeg._children[0].classList.contains('active'), 'Low активна');
  ok(vm.runInContext('qualityMax()', sandbox) === 600, 'low → потолок 600 px');
  els.qualitySeg.dispatch('click', { target: els.qualitySeg._children[2] });
  ok(api.state.quality === 'high', 'клик High → quality=high');
  ok(vm.runInContext('qualityMax()', sandbox) === 2048, 'high → потолок 2048 px');
  els.qualitySeg.dispatch('click', { target: els.qualitySeg._children[1] });
  ok(api.state.quality === 'standard', 'клик Standard → quality=standard');

  /* --- переключение языков --- */
  const langs = [
    ['ru', '🇷🇺', 'Ч/Б', 'Вставить в Figma'],
    ['it', '🇮🇹', 'B/N', 'Inserisci in Figma'],
    ['pt', '🇵🇹', 'P/B', 'Inserir no Figma'],
    ['fr', '🇫🇷', 'N/B', 'Insérer dans Figma'],
    ['zh', '🇨🇳', '黑白', '插入到 Figma'],
    ['ja', '🇯🇵', '白黒', 'Figmaに挿入'],
    ['en', '🇬🇧', 'B/W', 'Insert into Figma']
  ];
  for (const [code, flag, bw, insert] of langs) {
    vm.runInContext(`setLang('${code}')`, sandbox);
    await wait(50);
    ok(api.LANG() === code, code + ': язык применён');
    ok(els.langFlag.textContent === flag, code + ': флаг ' + flag);
    ok(els.modeSeg._children[0].textContent === bw, code + ': режим B/W = «' + bw + '»');
    ok(els.insertBtn.textContent === insert, code + ': вставка = «' + insert + '»');
  }
  // CJK fallback класс
  vm.runInContext(`setLang('zh')`, sandbox);
  ok(document.body.classList.contains('lang-cjk'), 'zh: класс lang-cjk (CJK-шрифты)');
  vm.runInContext(`setLang('en')`, sandbox);
  ok(!document.body.classList.contains('lang-cjk'), 'en: класс lang-cjk снят');

  /* --- привязка языка к пользователю --- */
  ok(cache['lang'] === 'en', 'язык сохранён в clientStorage: ' + cache['lang']);
  vm.runInContext(`setLang('fr')`, sandbox);
  await wait(50);
  ok(cache['lang'] === 'fr', 'язык обновлён в clientStorage: fr');

  /* --- тёмная тема, логотип, шрифт --- */
  ok(html.includes('--bg: #ffffff'), 'белый фон в CSS');
  ok(html.includes('#11A5CA'), 'кнопки #11A5CA в CSS');
  ok(html.includes('#0E8FB0'), 'градиент #0E8FB0 в CSS');
  ok(html.includes('data:image/png;base64,'), 'логотип вшит');
  ok(html.includes('Montserrat') && html.includes('data:font/woff2'), 'шрифт Montserrat вшит');

  /* --- звезда: надпись ↔ тумблер --- */
  const starBtn = els.shapeSeg._children[3];
  ok(els.starSwitch.classList.contains('knob5'), 'тумблер: 5 по умолчанию (knob справа)');
  // активируем звезду
  els.shapeSeg.dispatch('click', { target: starBtn });
  await wait(300);
  ok(api.state.shape === 'star5', 'выбрана звезда 5');
  ok(starBtn.classList.contains('active'), 'кнопка звезды активна');
  // клик по тумблеру → 4
  els.shapeSeg.dispatch('click', { target: els.starSwitch });
  await wait(300);
  ok(api.state.shape === 'star4', 'тумблер переключил на 4');
  ok(els.starKnob.textContent === '4' && !els.starSwitch.classList.contains('knob5'), 'knob показывает 4, слева');
  // ещё клик → 5
  els.shapeSeg.dispatch('click', { target: els.starSwitch });
  await wait(300);
  ok(api.state.shape === 'star5' && els.starKnob.textContent === '5', 'тумблер вернул 5');
  // другая форма → звезда неактивна
  els.shapeSeg.dispatch('click', { target: els.shapeSeg._children[0] });
  await wait(300);
  ok(api.state.shape === 'circle' && !starBtn.classList.contains('active'), 'круг: звезда неактивна');

  /* --- триал 5 + блокировка + кнопка покупки --- */
  vm.runInContext("setLang('en')", sandbox);
  await wait(50);
  let inserted = 0;
  for (let i = 0; i < 7; i++) {
    if (api.lic.locked) break;
    vm.runInContext('state.hasImage = true; state.finalSvg = "<svg width=\\"10\\" height=\\"10\\"/>"; state.finalAscii = null; state.busy = false;', sandbox);
    els.insertBtn.disabled = false;
    els.insertBtn.dispatch('click');
    await wait(250);
    inserted++;
  }
  ok(inserted === 5, 'вставок: 5 (получено ' + inserted + ')');
  const svgMsgs = sent.filter((m) => m.pluginMessage && m.pluginMessage.type === 'insert-svg');
  ok(svgMsgs.length === 5, 'insert-svg отправлен 5 раз из UI');
  ok(api.lic.locked === true, 'заблокировано');
  ok(!els.licCard.classList.contains('hidden'), 'экран блокировки показан');
  ok(els.buyBtn.textContent.includes('Get full access'), 'кнопка покупки: ' + els.buyBtn.textContent);
  // клик по покупке → сообщение open-url
  sent.length = 0;
  els.buyBtn.dispatch('click');
  await wait(50);
  const openUrl = sent.map((m) => m.pluginMessage).find((m) => m.type === 'open-url');
  ok(openUrl && typeof openUrl.url === 'string' && openUrl.url.indexOf('http') === 0, 'open-url отправлен: ' + (openUrl && openUrl.url));

  /* --- слайдеры точек и масштаб --- */
  ok(els.bwPoints && els.zoom && els.pvNa, 'слайдеры «Points» и «Zoom», плашка pvNa есть');

  /* --- цвет-halftone: превью недоступно --- */
  vm.runInContext("setLang('en')", sandbox);
  await wait(50);
  els.htOn.checked = true; els.htOn.dispatch('change');
  els.modeSeg.dispatch('click', { target: els.modeSeg._children[1] }); // color
  vm.runInContext('state.hasImage = true; state.working = { data: new Uint8ClampedArray(4), width: 1, height: 1 }; doTrace();', sandbox);
  await wait(100);
  ok(!els.pvNa.classList.contains('hidden'), 'цвет-halftone: превью недоступно (плашка видна)');
  ok(els.pvNa.textContent.indexOf('Preview is unavailable') === 0, 'текст плашки: ' + els.pvNa.textContent);
  els.htOn.checked = false; els.htOn.dispatch('change');
  vm.runInContext('doTrace();', sandbox);
  await wait(100);
  ok(els.pvNa.classList.contains('hidden'), 'после выключения halftone превью снова доступно');
  els.modeSeg.dispatch('click', { target: els.modeSeg._children[0] }); // bw
  await wait(300);

  /* --- активация ключа через сервер --- */
  // неверный формат
  els.licKey.value = '123';
  els.licActivateBtn.dispatch('click');
  await wait(200);
  ok(els.licMsg.className.includes('err') && els.licMsg.textContent.length > 0, 'активация: неверный формат → ошибка');
  // ключ не найден
  els.licKey.value = 'ZZZZ-ZZZZ-ZZZZ-ZZZZ';
  els.licActivateBtn.dispatch('click');
  await wait(200);
  ok(els.licMsg.textContent.includes('not found') || els.licMsg.textContent.includes('не найден'), 'активация: несуществующий ключ → «not found»: ' + els.licMsg.textContent);
  // ключ, привязанный к другому аккаунту
  els.licKey.value = 'CCCC-DDDD-EEEE-FFFF';
  els.licActivateBtn.dispatch('click');
  await wait(200);
  ok(els.licMsg.textContent.toLowerCase().includes('bound') || els.licMsg.textContent.includes('привязан'), 'активация: чужой ключ → «bound»: ' + els.licMsg.textContent);
  // успешная активация Deluxe
  els.licKey.value = 'AAAA-BBBB-CCCC-DDDD';
  els.licActivateBtn.dispatch('click');
  await wait(300);
  ok(api.lic.licensed === true && api.lic.tier === 'deluxe', 'активация: Deluxe');
  ok(els.licCard.classList.contains('hidden'), 'активация: экран скрыт');
  ok(els.licBadge.innerHTML.includes('DELUXE') && els.licBadge.innerHTML.includes('unlimited'), 'бейдж DELUXE · unlimited');
  ok(!els.modeSeg._children[2].classList.contains('hidden'), 'Deluxe: ASCII доступен');
  ok(!els.cardHt.classList.contains('hidden'), 'Deluxe: halftone доступен');
  // безлимит: вставка не списывает триал
  const remBefore = api.lic.trialRemaining;
  vm.runInContext('state.hasImage = true; state.finalSvg = "<svg width=\\"10\\" height=\\"10\\"/>"; state.finalAscii = null; state.busy = false;', sandbox);
  els.insertBtn.disabled = false;
  els.insertBtn.dispatch('click');
  await wait(250);
  ok(api.lic.trialRemaining === remBefore, 'с лицензией триал не списывается');

  console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
  process.exit(fail ? 1 : 0);
}
runAll().catch((e) => { console.error('Харнесс упал:', e); process.exit(1); });
