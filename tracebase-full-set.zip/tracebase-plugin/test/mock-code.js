/* Харнесс песочницы TraceBase: полный цикл (selection → image → insert-svg/ascii)
   с имитацией dynamic-page (страница требует loadAsync перед вставкой). */
'use strict';
const fs = require('fs');
const vm = require('vm');
const msgs = [];
let loadAsyncCalls = 0;
let insertedOk = 0;
let errors = [];
const imageNode = {
  type: 'IMAGE', name: 'photo.jpg', width: 800, height: 600,
  image: { hash: 'h1', getBytesAsync: async () => new Uint8Array([1,2,3]) },
  absoluteTransform: [[1,0,100],[0,1,200]],
  remove() {}
};
const page = { selection: [], loadAsync: async () => { loadAsyncCalls++; } };
const figmaMock = {
  currentUser: { id: 'figma-user-1' },
  currentPage: page,
  on: (evt, cb) => { figmaMock._selCb = cb; },
  showUI: (html, opts) => {},
  ui: { postMessage: (m) => { msgs.push(m); if (m.type === 'inserted') insertedOk++; if (m.type === 'error') errors.push(m.message); }, onmessage: null, resize: () => {} },
  clientStorage: (() => { const store = {}; return {
    getAsync: async (k) => (k in store ? store[k] : null),
    setAsync: async (k, v) => { store[k] = v; }
  }; })(),
  getImageByHash: () => ({ getBytesAsync: async () => new Uint8Array([9,9]) }),
  listAvailableFontsAsync: async () => [{ fontName: { family: 'Roboto Mono', style: 'Regular' } }],
  loadFontAsync: async () => {},
  createNodeFromSvg: (svg) => {
    if (loadAsyncCalls === 0) throw new Error('Page not loaded: call loadAsync first');
    return { name: '', x: 0, y: 0 };
  },
  createText: () => {
    if (loadAsyncCalls === 0) throw new Error('Page not loaded: call loadAsync first');
    return { name: '', x: 0, y: 0, fontSize: 10, lineHeight: null, textAutoResize: 'NONE', fills: [], fontName: null };
  },
  viewport: { scrollAndZoomIntoView: () => {} },
  openExternal: () => {}
};
const sandbox = { figma: figmaMock, console, Uint8Array, __html__: fs.readFileSync('ui.html','utf8') };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync('code.js','utf8'), sandbox, { filename: 'code.js' });
const wait = (ms) => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };
(async () => {
  figmaMock.currentPage.selection = [imageNode];
  await figmaMock._selCb();
  await wait(20);
  const sel = msgs.filter(m => m.type === 'selection').pop();
  ok(sel && sel.has === true && sel.name === 'photo.jpg', 'selection передано (async sendSelection + ensurePage)');
  ok(loadAsyncCalls >= 1, 'loadAsync вызван при чтении selection');

  figmaMock.ui.onmessage({ type: 'insert-svg', svg: '<svg width="800" height="600"><path d="M0 0L10 10Z"/></svg>', name: 'photo.jpg' });
  await wait(30);
  ok(insertedOk >= 1, 'insert-svg: createNodeFromSvg отработал, inserted получен');
  ok(errors.length === 0, 'нет ошибок вставки: ' + errors.join(', '));

  figmaMock.ui.onmessage({ type: 'insert-ascii', text: '@@', fontSize: 12, invert: false, family: 'Roboto Mono', name: 'x' });
  await wait(30);
  ok(insertedOk >= 2, 'insert-ascii: createText отработал, inserted получен');

  figmaMock.ui.onmessage({ type: 'get-user' });
  await wait(20);
  const u = msgs.filter(m => m.type === 'user').pop();
  ok(u && u.id === 'figma-user-1' && u.real === true, 'get-user: real ID');

  figmaMock.ui.onmessage({ type: 'cache-set', key: 'trial', value: { count: 1 } });
  await wait(20);
  figmaMock.ui.onmessage({ type: 'cache-get', key: 'trial' });
  await wait(20);
  const cg = msgs.filter(m => m.type === 'cache-get').pop();
  ok(cg && cg.value && cg.value.count === 1, 'cache-set/get через clientStorage');

  console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('Харнесс упал:', e); process.exit(1); });
