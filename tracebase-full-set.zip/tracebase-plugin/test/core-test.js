#!/usr/bin/env node
/* Тест ядра TraceBase: стыковка цветов (нет проплешин) и гладкость границ.
   Запуск: node test/core-test.js */
'use strict';
const C = require('../src/core.js');

let pass = 0, fail = 0;
const ok = (c, n) => { c ? (pass++, console.log('  ✓ ' + n)) : (fail++, console.error('  ✗ FAIL: ' + n)); };

function makeImage(w, h, fn) {
  const data = new Uint8ClampedArray(w * h * 4);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const [r, g, b] = fn(x, y);
    const i = (y * w + x) * 4;
    data[i] = r; data[i + 1] = g; data[i + 2] = b; data[i + 3] = 255;
  }
  return { data, width: w, height: h };
}

// bbox path-data
function bboxOf(d) {
  let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
  for (const c of C.parsePathData(d)) {
    if (c.cmd === 'Z') continue;
    minX = Math.min(minX, c.x, c.x1 !== undefined ? c.x1 : 1e9, c.x2 !== undefined ? c.x2 : 1e9);
    maxX = Math.max(maxX, c.x, c.x1 !== undefined ? c.x1 : -1e9, c.x2 !== undefined ? c.x2 : -1e9);
    minY = Math.min(minY, c.y, c.y1 !== undefined ? c.y1 : 1e9, c.y2 !== undefined ? c.y2 : 1e9);
    maxY = Math.max(maxY, c.y, c.y1 !== undefined ? c.y1 : -1e9, c.y2 !== undefined ? c.y2 : -1e9);
  }
  return [minX, minY, maxX, maxY];
}

console.log('--- стыковка двух цветов (нет проплешин) ---');
{
  const rgbOf = (f) => { const m = f.match(/rgb\((\d+),(\d+),(\d+)\)/); return m ? [+m[1], +m[2], +m[3]] : null; };
  const notBg = (p) => !/M0 0H/.test(p.d);
  const w = 120, h = 80;
  // левая половина красная, правая синяя — граница ровная по X=60
  const img = makeImage(w, h, (x) => (x < 60 ? [220, 30, 30] : [30, 60, 220]));
  const paths = C.traceColor(img, 2, 100, 100, 'simple');
  // 3 пути: фоновый слой (ПЕРВЫМ, внизу) + красный + синий
  ok(paths.length === 3, '2 цвета + фоновый слой (' + paths.length + ')');
  ok(/^M0 0H/.test(paths[0].d), 'фоновый слой — первый (рисуется внизу, не перекрывает картинку)');
  // регулировка стыковки: overlap=0 → ровно по границе, overlap=2 → перекрытие
  const paths0 = C.traceColor(img, 2, 100, 100, 'simple', 0);
  const b0 = bboxOf(paths0.find((p) => p.fill.includes('220,30,30') || /220,\s*3[0-9],\s*3[0-9]/.test(p.fill)) ? paths0.find((p) => p.fill.includes('220') && !/M0 0H/.test(p.d)).d : paths0[1].d);
  ok(paths0.length === 3, 'overlap=0: 3 пути');
  const red0 = paths0.find((p) => { const c = rgbOf(p.fill); return !/M0 0H/.test(p.d) && c && c[0] > 150; });
  const blue0 = paths0.find((p) => { const c = rgbOf(p.fill); return !/M0 0H/.test(p.d) && c && c[2] > 150; });
  ok(bboxOf(red0.d)[2] - bboxOf(blue0.d)[0] <= 0.5, 'overlap=0: перекрытие ~0 (без утолщения)');
  const paths2 = C.traceColor(img, 2, 100, 100, 'simple', 2);
  const red2 = paths2.find((p) => { const c = rgbOf(p.fill); return !/M0 0H/.test(p.d) && c && c[0] > 150; });
  const blue2 = paths2.find((p) => { const c = rgbOf(p.fill); return !/M0 0H/.test(p.d) && c && c[2] > 150; });
  ok(bboxOf(red2.d)[2] - bboxOf(blue2.d)[0] > 0.5, 'overlap=2: перекрытие есть (стыковка)');
  const red = paths.find((p) => { const c = rgbOf(p.fill); return notBg(p) && c && c[0] > 150 && c[1] < 100 && c[2] < 100; });
  const blue = paths.find((p) => { const c = rgbOf(p.fill); return notBg(p) && c && c[2] > 150 && c[0] < 100 && c[1] < 100; });
  ok(red && blue, 'найдены красный и синий пути');
  const rb = bboxOf(red.d), bb = bboxOf(blue.d);
  ok(rb[2] >= 60, 'красный доходит до стыка 60 (maxX=' + rb[2].toFixed(1) + ')');
  ok(bb[0] <= 60, 'синий начинается до стыка 60 (minX=' + bb[0].toFixed(1) + ')');
  // перекрытие на стыке: красный maxX > синий minX → белых дыр нет
  ok(rb[2] > bb[0], 'перекрытие на стыке: ' + rb[2].toFixed(1) + ' > ' + bb[0].toFixed(1) + ' (нет проплешин)');
}

console.log('--- гладкость диагональной границы (без лесенки) ---');
{
  const w = 100, h = 100;
  // диагональная граница: x + y < 100 → красный, иначе синий
  const img = makeImage(w, h, (x, y) => (x + y < 100 ? [220, 30, 30] : [30, 60, 220]));
  const paths = C.traceColor(img, 2, 100, 100, 'simple');
  ok(paths.length >= 2, 'пути есть');
  // больший путь (красный треугольник) — считаем вершины: лесенка дала бы сотни точек
  const big = paths.reduce((a, p) => (bboxOf(p.d)[2] - bboxOf(p.d)[0]) > (bboxOf(a.d)[2] - bboxOf(a.d)[0]) ? p : a);
  const verts = (C.parsePathData(big.d).filter((c) => c.cmd === 'L' || c.cmd === 'C')).length;
  ok(verts < 80, 'вершин на диагонали умеренно (' + verts + ' < 80) — нет лесенки');
  // пути валидны
  for (const p of paths) ok(/^M/.test(p.d) && /Z$/.test(p.d), 'path валиден');
}

console.log('--- smoothMaskCorners ---');
{
  // шахматный уголок 2×2 с 3 залитыми → станет квадратом
  const w = 4, h = 4;
  const m = new Uint8Array(w * h);
  m[0] = 1; m[1] = 1; m[w] = 1; // m[w+1] = 0
  const s = C.smoothMaskCorners(m, w, h);
  ok(s[w + 1] === 1, 'уголок 2×2 заполнен');
  ok(s[0] === 1 && s[1] === 1 && s[w] === 1, 'остальные не тронуты');
}

console.log('--- ч/б не сломан ---');
{
  const w = 64, h = 64;
  const img = makeImage(w, h, (x, y) => (Math.hypot(x - 32, y - 32) < 22 ? [10, 10, 10] : [250, 250, 250]));
  const paths = C.traceBW(img, 0, 255, false, 100, 100);
  ok(paths.length === 1, 'круг → 1 path');
}

console.log('--- ч/б инверсия: фигура, а не цвет ---');
{
  const w = 64, h = 64;
  // белый круг на чёрном фоне; порог [128,255] → чернила = белый круг
  const img = makeImage(w, h, (x, y) => (Math.hypot(x - 32, y - 32) < 22 ? [250, 250, 250] : [10, 10, 10]));
  const normal = C.traceBW(img, 128, 255, false, 0, 100);
  const inv = C.traceBW(img, 128, 255, true, 0, 100);
  ok(normal.length >= 1 && normal.every((p) => p.fill === '#111111'), 'без инверсии фигура чёрная');
  ok(inv.length >= 1 && inv.every((p) => p.fill === '#111111'), 'при инверсии фигура тоже чёрная (#111111)');
  const b0 = bboxOf(normal[0].d);
  const b1 = bboxOf(inv[0].d);
  ok(b0[0] > 1 && b0[2] < 63 && b1[0] <= 0 && b1[2] >= 64, 'инверсия меняет фигуру: круг ↔ фон');
  // halftone ч/б: точки при инверсии тоже чёрные
  const dots = C.traceHalftone(img, 8, 'circle', true, false, 0, 128);
  ok(dots.length > 0 && dots.every((p) => p.fill === '#111111'), 'halftone ч/б при инверсии: точки чёрные');
}

console.log('--- классическое скругление (Simple) ---');
{
  const L = 20;
  // острый пик (поворот 150°) при smoothing=100 → остаётся углом
  const rad150 = 150 * Math.PI / 180;
  const sharp = [[0,0],[L,0],[L+Math.cos(rad150)*L, Math.sin(rad150)*L]];
  const dSharp = C.loopToPathData(sharp, 100);
  ok(!/C/.test(dSharp), 'острый пик остаётся углом (нет C)');
  // плавный изгиб (поворот 30°) → кривая
  const rad30 = 30 * Math.PI / 180;
  const smooth = [[0,0],[L,0],[L+Math.cos(rad30)*L, Math.sin(rad30)*L]];
  ok(/C/.test(C.loopToPathData(smooth, 100)), 'плавный изгиб → кривая C');
  // круг из 8 точек → 8 C-команд
  const circle = [];
  for (let i=0;i<8;i++){ const a=i/8*Math.PI*2; circle.push([30+Math.cos(a)*25, 30+Math.sin(a)*25]); }
  ok((C.loopToPathData(circle, 100).match(/C/g)||[]).length === 8, 'круг → 8 кривых');
}

console.log('--- Adaptive: пики сохраняются ---');
{
  const pts = [];
  for (let i=0;i<10;i++){
    const a = i/10*Math.PI*2 - Math.PI/2;
    const r = i%2===0 ? 40 : 18;
    pts.push([50+Math.cos(a)*r, 50+Math.sin(a)*r]);
  }
  const simp = C.adaptiveSimplify(pts, 1.0);
  const outer = simp.filter((p) => Math.hypot(p[0]-50, p[1]-50) > 30).length;
  ok(outer === 5, 'Adaptive: все 5 пиков звезды сохранены (' + outer + ')');
}

console.log('\nРезультат: ' + pass + ' пройдено, ' + fail + ' ошибок');
process.exit(fail ? 1 : 0);

